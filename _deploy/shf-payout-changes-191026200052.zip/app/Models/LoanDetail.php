<?php

namespace App\Models;

use App\Traits\HasAuditColumns;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Collection;

class LoanDetail extends Model
{
    use HasAuditColumns, SoftDeletes;

    const STATUS_ACTIVE = 'active';

    const STATUS_COMPLETED = 'completed';

    const STATUS_REJECTED = 'rejected';

    const STATUS_CANCELLED = 'cancelled';

    const STATUS_ON_HOLD = 'on_hold';

    const STATUS_PARTIAL_DISBURSED = 'partial_disbursed';

    const STATUSES = [
        self::STATUS_ACTIVE,
        self::STATUS_PARTIAL_DISBURSED,
        self::STATUS_COMPLETED,
        self::STATUS_REJECTED,
        self::STATUS_CANCELLED,
        self::STATUS_ON_HOLD,
    ];

    /**
     * Statuses for loans still actively being worked (not paused, not closed).
     * `partial_disbursed` is a monotonic in-flight state: disbursement has
     * started but the loan is not yet fully disbursed + OTC-settled. Treated as
     * active work everywhere (listings, dashboards, "my work").
     *
     * @var array<int, string>
     */
    const IN_FLIGHT_STATUSES = [
        self::STATUS_ACTIVE,
        self::STATUS_PARTIAL_DISBURSED,
    ];

    /**
     * Terminal statuses where the loan is no longer being worked.
     * Tasks, stage assignments, and queries for these loans should be
     * hidden from "my work" listings.
     *
     * @var array<int, string>
     */
    const CLOSED_STATUSES = [
        self::STATUS_COMPLETED,
        self::STATUS_REJECTED,
        self::STATUS_CANCELLED,
    ];

    /**
     * Statuses that must NOT receive a payout — paused (on_hold) or closed
     * unfavourably (cancelled / rejected). Excluded from both the Payout Runs
     * engine and the Bank Reconciliation match (surfaced there with their status).
     *
     * @var array<int, string>
     */
    const PAYOUT_EXCLUDED_STATUSES = [
        self::STATUS_CANCELLED,
        self::STATUS_ON_HOLD,
        self::STATUS_REJECTED,
    ];

    const STATUS_LABELS = [
        'active' => ['label' => 'Active', 'color' => 'primary'],
        'partial_disbursed' => ['label' => 'Partially Disbursed', 'color' => 'info'],
        'completed' => ['label' => 'Completed', 'color' => 'success'],
        'rejected' => ['label' => 'Rejected', 'color' => 'danger'],
        'cancelled' => ['label' => 'Cancelled', 'color' => 'secondary'],
        'on_hold' => ['label' => 'On Hold', 'color' => 'warning'],
    ];

    const CUSTOMER_TYPE_LABELS = [
        'proprietor' => 'Proprietor / માલિકી',
        'partnership_llp' => 'Partnership / LLP / ભાગીદારી',
        'pvt_ltd' => 'Pvt. Ltd. / પ્રા. લિ.',
        'salaried' => 'Salaried / પગારદાર',
    ];

    protected $fillable = [
        'loan_number', 'quotation_id', 'customer_id', 'customer_kyc_details_id', 'branch_id', 'bank_id', 'product_id', 'location_id',
        'customer_name', 'customer_type', 'customer_phone', 'customer_email', 'date_of_birth', 'pan_number',
        'loan_amount', 'original_loan_amount', 'sanctioned_amount', 'disbursed_amount', 'status', 'is_sanctioned', 'current_stage', 'bank_name', 'roi_min', 'roi_max',
        'total_charges', 'application_number', 'assigned_bank_employee',
        'due_date', 'expected_docket_date', 'rejected_at', 'rejected_by', 'rejected_stage', 'rejection_reason',
        'status_reason', 'status_changed_at', 'status_changed_by',
        'created_by', 'assigned_advisor', 'dme_user_id', 'payout_user_id', 'notes', 'workflow_config',
    ];

    protected function casts(): array
    {
        return [
            'loan_amount' => 'integer',
            'original_loan_amount' => 'integer',
            'sanctioned_amount' => 'integer',
            'disbursed_amount' => 'integer',
            'is_sanctioned' => 'boolean',
            'roi_min' => 'decimal:2',
            'roi_max' => 'decimal:2',
            'due_date' => 'date',
            'date_of_birth' => 'date',
            'expected_docket_date' => 'date',
            'rejected_at' => 'datetime',
            'status_changed_at' => 'datetime',
            'workflow_config' => 'array',
        ];
    }

    // Relationships

    public function quotation(): BelongsTo
    {
        return $this->belongsTo(Quotation::class);
    }

    public function branch(): BelongsTo
    {
        return $this->belongsTo(Branch::class);
    }

    public function bank(): BelongsTo
    {
        return $this->belongsTo(Bank::class);
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    public function location(): BelongsTo
    {
        return $this->belongsTo(Location::class);
    }

    public function customerKycDetails(): BelongsTo
    {
        return $this->belongsTo(CustomerKycDetail::class, 'customer_kyc_details_id');
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function advisor(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assigned_advisor');
    }

    public function dme(): BelongsTo
    {
        return $this->belongsTo(User::class, 'dme_user_id');
    }

    public function payoutUser(): BelongsTo
    {
        return $this->belongsTo(User::class, 'payout_user_id');
    }

    public function bankEmployee(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assigned_bank_employee');
    }

    public function statusChangedByUser(): BelongsTo
    {
        return $this->belongsTo(User::class, 'status_changed_by');
    }

    public function documents(): HasMany
    {
        return $this->hasMany(LoanDocument::class, 'loan_id');
    }

    public function stageAssignments(): HasMany
    {
        return $this->hasMany(StageAssignment::class, 'loan_id');
    }

    public function progress(): HasOne
    {
        return $this->hasOne(LoanProgress::class, 'loan_id');
    }

    public function stageTransfers(): HasMany
    {
        return $this->hasMany(StageTransfer::class, 'loan_id');
    }

    public function stageQueries(): HasMany
    {
        return $this->hasMany(StageQuery::class, 'loan_id');
    }

    public function remarks(): HasMany
    {
        return $this->hasMany(Remark::class, 'loan_id');
    }

    public function valuationDetails(): HasMany
    {
        return $this->hasMany(ValuationDetail::class, 'loan_id');
    }

    public function disbursement(): HasOne
    {
        return $this->hasOne(DisbursementDetail::class, 'loan_id');
    }

    public function disbursementEntries(): HasMany
    {
        return $this->hasMany(DisbursementEntry::class, 'loan_id');
    }

    public function payouts(): HasMany
    {
        return $this->hasMany(LoanPayout::class, 'loan_id');
    }

    /**
     * True when any active disbursement tranche is already covered by a finalized
     * payout (a per-loan ledger row or a payout run). Used to block a stage reset
     * past disbursement and to hide the reset UI — reversing those tranches would
     * orphan the payout ledger.
     */
    public function hasFinalizedPayout(): bool
    {
        return $this->disbursementEntries()
            ->where(function ($query) {
                $query->whereNotNull('loan_payout_id')->orWhereNotNull('payout_run_id');
            })
            ->exists();
    }

    /**
     * Keep disbursement entry rows' is_active flag in sync with the loan
     * status: cancelled / rejected / on_hold deactivate, active / completed
     * reactivate. Bulk query update — no per-row audit stamping intended.
     */
    protected static function booted(): void
    {
        static::updated(function (self $loan): void {
            if (! $loan->wasChanged('status')) {
                return;
            }

            $loan->disbursementEntries()->update([
                'is_active' => ! in_array($loan->status, [
                    self::STATUS_CANCELLED, self::STATUS_REJECTED, self::STATUS_ON_HOLD,
                ]),
            ]);
        });
    }

    // Stage helpers

    public function getStageAssignment(string $key): ?StageAssignment
    {
        return $this->stageAssignments()->where('stage_key', $key)->first();
    }

    // Ownership

    public function getCurrentOwnerAttribute(): ?User
    {
        // Prefer the assigned advisor; fall back to loan creator.
        // Use the already-loaded `advisor` relation so list pages don't run
        // one extra query per loan.
        return $this->advisor ?? $this->creator;
    }

    /**
     * The user currently holding the active stage assignment (the "task owner"),
     * as opposed to current_owner which is the loan's advisor/creator. Resolves
     * the same assignment as time_with_current_owner — current-stage assignment,
     * falling back to the first in-progress parallel sub-stage. For the full set
     * during parallel processing use currentTaskOwners.
     */
    public function getCurrentTaskOwnerAttribute(): ?User
    {
        return $this->current_task_owners->first();
    }

    /**
     * Every user actively holding work on the loan right now (deduped):
     *  - the assignee of the current-stage assignment, and
     *  - during parallel_processing, the assignee of every in-progress sub-stage.
     *
     * @return Collection<int, User>
     */
    public function getCurrentTaskOwnersAttribute(): Collection
    {
        return $this->stageAssignments
            ->filter(function ($a) {
                if (! $a->assigned_to) {
                    return false;
                }
                if ($a->stage_key === $this->current_stage) {
                    return true;
                }

                return $this->current_stage === 'parallel_processing'
                    && $a->parent_stage_key === 'parallel_processing'
                    && $a->status === 'in_progress';
            })
            ->sortBy('stage_key')
            ->map(fn ($a) => $a->assignee)
            ->filter()
            ->unique('id')
            ->values();
    }

    public function getTimeWithCurrentOwnerAttribute(): string
    {
        $assignment = $this->stageAssignments
            ->where('stage_key', $this->current_stage)
            ->first();

        // For parallel_processing — use first active sub-stage
        if ($this->current_stage === 'parallel_processing' && ! $assignment?->assigned_to) {
            $assignment = $this->stageAssignments
                ->where('parent_stage_key', 'parallel_processing')
                ->where('status', 'in_progress')
                ->sortBy('stage_key')
                ->first();
        }

        if (! $assignment || ! $assignment->assigned_to) {
            return '—';
        }

        $lastTransfer = $assignment->transfers()
            ->where('transferred_to', $assignment->assigned_to)
            ->latest('created_at')
            ->first();

        $since = $lastTransfer?->created_at ?? $assignment->started_at ?? $assignment->created_at;

        if (! $since) {
            return '—';
        }

        $diff = $since->diff(now());
        $parts = [];
        if ($diff->d > 0) {
            $parts[] = $diff->d.'d';
        }
        if ($diff->h > 0) {
            $parts[] = $diff->h.'h';
        }
        $parts[] = $diff->i.'m';

        return implode(' ', $parts);
    }

    public function getTotalLoanTimeAttribute(): string
    {
        if (! $this->created_at) {
            return '—';
        }

        // For closed loans, measure to updated_at (when status changed)
        $endTime = in_array($this->status, [self::STATUS_COMPLETED, self::STATUS_REJECTED, self::STATUS_CANCELLED, self::STATUS_ON_HOLD])
            ? ($this->status_changed_at ?? $this->updated_at)
            : now();

        $diff = $this->created_at->diff($endTime);
        $parts = [];
        if ($diff->days > 0) {
            $parts[] = $diff->days.'d';
        }
        if ($diff->h > 0) {
            $parts[] = $diff->h.'h';
        }
        $parts[] = $diff->i.'m';

        return implode(' ', $parts);
    }

    // Accessors

    public function getFormattedAmountAttribute(): string
    {
        return "₹\u{00A0}".$this->formatIndianNumber($this->loan_amount);
    }

    /**
     * Distinct loan account number(s) across the loan's active disbursement
     * tranches, comma-joined; empty string before any disbursement. There is no
     * single account-number column — it is captured per tranche.
     */
    public function getLoanAccountNumbersAttribute(): string
    {
        return $this->disbursementEntries
            ->where('is_active', true)
            ->pluck('loan_account_number')
            ->map(fn ($n) => trim((string) $n))
            ->filter()
            ->unique()
            ->values()
            ->implode(', ');
    }

    /**
     * Formatted original (as-applied) loan amount, or null when not captured.
     * Diverges from loan_amount only when someone edits the amount at KFS.
     */
    public function getFormattedOriginalAmountAttribute(): ?string
    {
        return $this->original_loan_amount !== null
            ? "₹\u{00A0}".$this->formatIndianNumber($this->original_loan_amount)
            : null;
    }

    /**
     * Formatted sanctioned amount, or null when not yet captured.
     */
    public function getFormattedSanctionedAmountAttribute(): ?string
    {
        return $this->sanctioned_amount !== null
            ? "₹\u{00A0}".$this->formatIndianNumber($this->sanctioned_amount)
            : null;
    }

    /**
     * Formatted disbursed amount, or null when not yet disbursed.
     */
    public function getFormattedDisbursedAmountAttribute(): ?string
    {
        return $this->disbursed_amount !== null
            ? "₹\u{00A0}".$this->formatIndianNumber($this->disbursed_amount)
            : null;
    }

    public function getStatusLabelAttribute(): string
    {
        return self::STATUS_LABELS[$this->status]['label'] ?? ucfirst($this->status);
    }

    public function getStatusColorAttribute(): string
    {
        return self::STATUS_LABELS[$this->status]['color'] ?? 'secondary';
    }

    /**
     * "Partially Completed" — a derived sub-state of `partial_disbursed`: the loan
     * is not fully disbursed (gross < sanctioned target) yet every active tranche's
     * OTC is already settled (cheques cleared/skipped; fund transfers auto-settle),
     * so nothing is pending until the next disbursement. Not a stored status.
     */
    public function isPartiallyCompleted(): bool
    {
        if ($this->status !== self::STATUS_PARTIAL_DISBURSED) {
            return false;
        }

        $entries = $this->relationLoaded('disbursementEntries')
            ? $this->disbursementEntries->where('is_active', true)
            : $this->disbursementEntries()->where('is_active', true)->get();

        return $entries->isNotEmpty() && $entries->every(fn ($e) => $e->isOtcSettled());
    }

    public function getCustomerTypeLabelAttribute(): string
    {
        return self::CUSTOMER_TYPE_LABELS[$this->customer_type] ?? $this->customer_type;
    }

    public function getCurrentStageNameAttribute(): string
    {
        static $stageNames = null;
        if ($stageNames === null) {
            $stageNames = Stage::pluck('stage_name_en', 'stage_key')->toArray();
        }

        $baseName = $stageNames[$this->current_stage] ?? $this->current_stage;

        // For parallel_processing — show active sub-stage names with role suffixes
        if ($this->current_stage === 'parallel_processing') {
            $activeSubs = $this->stageAssignments
                ->where('parent_stage_key', 'parallel_processing')
                ->where('status', 'in_progress');

            if ($activeSubs->isNotEmpty()) {
                $subNames = $activeSubs->map(function ($sa) use ($stageNames) {
                    $name = $stageNames[$sa->stage_key] ?? $sa->stage_key;
                    $suffix = self::roleSuffix(self::userRoleSlug($sa->assignee));

                    return "{$name} ({$suffix})";
                })->implode(', ');

                return "{$baseName} ({$subNames})";
            }

            return $baseName;
        }

        // For all other stages — show role suffix
        $assignment = $this->stageAssignments
            ->where('stage_key', $this->current_stage)
            ->first();

        if ($assignment?->assignee) {
            $suffix = self::roleSuffix(self::userRoleSlug($assignment->assignee));

            return "{$baseName} ({$suffix})";
        }

        return $baseName;
    }

    public static function roleSuffix(?string $roleSlug): string
    {
        return match ($roleSlug) {
            'bank_employee' => 'Bank Review',
            'office_employee' => 'Office',
            'bdh' => 'BDH',
            default => 'SHF',
        };
    }

    /**
     * Get the primary workflow role slug for a user (for display purposes).
     */
    public static function userRoleSlug(?User $user): string
    {
        if (! $user) {
            return 'SHF';
        }

        // Check new roles system first
        if ($user->relationLoaded('roles') && $user->roles->isNotEmpty()) {
            $priorityOrder = ['bank_employee', 'office_employee', 'bdh', 'branch_manager', 'loan_advisor'];
            foreach ($priorityOrder as $slug) {
                if ($user->roles->contains('slug', $slug)) {
                    return $slug;
                }
            }
        }

        // Fall back to first workflow role
        $workflowRole = $user->roles->whereNotIn('slug', ['super_admin', 'admin'])->first();

        return $workflowRole?->slug ?? 'loan_advisor';
    }

    public static function stageBadgeClass(string $stageKey): string
    {
        $classes = [
            'inquiry' => 'shf-badge-stage-inquiry',
            'document_selection' => 'shf-badge-stage-doc-selection',
            'document_collection' => 'shf-badge-stage-doc-collection',
            'parallel_processing' => 'shf-badge-stage-app-number',
            'app_number' => 'shf-badge-stage-app-number',
            'bsm_osv' => 'shf-badge-stage-bsm-osv',
            'legal_verification' => 'shf-badge-stage-legal',
            'technical_valuation' => 'shf-badge-stage-valuation',
            'property_valuation' => 'shf-badge-stage-valuation',
            'sanction_decision' => 'shf-badge-stage-sanction-decision',
            'rate_pf' => 'shf-badge-stage-rate-pf',
            'sanction' => 'shf-badge-stage-sanction',
            'docket' => 'shf-badge-stage-docket',
            'kfs' => 'shf-badge-stage-kfs',
            'esign' => 'shf-badge-stage-esign',
            'disbursement' => 'shf-badge-stage-disbursement',
            'otc_clearance' => 'shf-badge-stage-otc',
        ];

        return $classes[$stageKey] ?? 'shf-badge-gray';
    }

    /**
     * Get stage badge HTML for loan listing.
     * For parallel_processing: returns individual sub-stage badges (no parent label).
     * For other stages: returns a single badge with role suffix.
     */
    public function getStageBadgeHtmlAttribute(): string
    {
        static $stageNames = null;
        if ($stageNames === null) {
            $stageNames = Stage::pluck('stage_name_en', 'stage_key')->toArray();
        }

        if ($this->current_stage === 'parallel_processing') {
            $activeSubs = $this->stageAssignments
                ->where('parent_stage_key', 'parallel_processing')
                ->where('status', 'in_progress');

            if ($activeSubs->isEmpty()) {
                $baseName = $stageNames['parallel_processing'] ?? 'Parallel Processing';

                return '<span class="shf-badge shf-badge-stage-app-number shf-text-2xs">'.$baseName.'</span>';
            }

            return $activeSubs->map(function ($sa) use ($stageNames) {
                $name = $stageNames[$sa->stage_key] ?? $sa->stage_key;
                $suffix = self::roleSuffix(self::userRoleSlug($sa->assignee));
                $cssClass = self::stageBadgeClass($sa->stage_key);

                return '<span class="shf-badge '.$cssClass.' shf-text-2xs">'.$name.' ('.$suffix.')</span>';
            })->implode(' ');
        }

        $baseName = $stageNames[$this->current_stage] ?? $this->current_stage;
        $cssClass = self::stageBadgeClass($this->current_stage);

        $assignment = $this->stageAssignments
            ->where('stage_key', $this->current_stage)
            ->first();

        if ($assignment?->assignee) {
            $suffix = self::roleSuffix(self::userRoleSlug($assignment->assignee));
            $baseName .= ' ('.$suffix.')';
        }

        return '<span class="shf-badge '.$cssClass.' shf-text-2xs">'.$baseName.'</span>';
    }

    // Edit restrictions

    /**
     * Whether the loan's basic details (customer info, bank, amount) can be edited.
     * Locked once application number sub-stage has been completed.
     */
    public function isBasicEditLocked(): bool
    {
        $appNumberAssignment = $this->stageAssignments
            ->where('stage_key', 'app_number')
            ->first();

        return $appNumberAssignment && $appNumberAssignment->status === 'completed';
    }

    /**
     * Get the stage key of the immediate previous stage that can be edited.
     * Returns null if no previous stage is editable.
     */
    public function getEditableStageKey(): ?string
    {
        $stageOrder = [
            'inquiry', 'document_selection', 'document_collection',
            'app_number', 'bsm_osv', 'legal_verification', 'technical_valuation',
            'rate_pf', 'sanction', 'docket', 'kfs', 'esign', 'disbursement', 'otc_clearance',
        ];

        $currentStage = $this->current_stage;

        // For parallel_processing, find the active sub-stages and allow editing app_number only if all subs are active
        if ($currentStage === 'parallel_processing') {
            $appNumber = $this->stageAssignments->where('stage_key', 'app_number')->first();
            if ($appNumber && $appNumber->status === 'in_progress') {
                // app_number is active — previous is document_collection
                return 'document_collection';
            }

            // app_number completed, others active — previous is app_number
            return 'app_number';
        }

        $currentIdx = array_search($currentStage, $stageOrder);
        if ($currentIdx === false || $currentIdx === 0) {
            return null;
        }

        return $stageOrder[$currentIdx - 1];
    }

    /**
     * Whether a specific completed stage can be edited.
     */
    public function canEditStage(string $stageKey): bool
    {
        if ($this->status !== self::STATUS_ACTIVE) {
            return false;
        }

        return $this->getEditableStageKey() === $stageKey;
    }

    // Static Methods

    public static function generateLoanNumber(): string
    {
        $prefix = 'SHF-'.now()->format('Ym').'-';

        // Highest existing counter for this month, compared NUMERICALLY. String
        // ordering breaks once the counter passes 9999 (e.g. '...-10000' sorts
        // below '...-9999'), which would otherwise regenerate a colliding number
        // and break all loan creation for the rest of the month. The counter is
        // everything after the prefix, so widths beyond 4 digits are handled.
        // A duplicate under concurrency is caught by the unique index and
        // retried at the creation site (see LoanConversionService).
        $maxNum = static::withTrashed()
            ->where('loan_number', 'like', $prefix.'%')
            ->pluck('loan_number')
            ->map(fn ($number) => (int) substr($number, strlen($prefix)))
            ->max() ?? 0;

        return $prefix.str_pad((string) ($maxNum + 1), 4, '0', STR_PAD_LEFT);
    }

    // Scopes

    /**
     * In-flight loans actively being worked: active + partial_disbursed
     * (excludes on_hold). A partially disbursed loan is still active work, so
     * it shows wherever `active` loans do (listings, dashboards, "my work").
     */
    public function scopeActive($query): void
    {
        $query->whereIn('status', self::IN_FLIGHT_STATUSES);
    }

    /**
     * Loans still being worked (not completed, rejected, or cancelled) —
     * includes on_hold and partial_disbursed.
     */
    public function scopeOpen($query): void
    {
        $query->whereNotIn('status', self::CLOSED_STATUSES);
    }

    /**
     * True when the disbursed total has exceeded the sanctioned amount.
     * Over-disbursement is allowed; the UI surfaces a warning label.
     */
    public function isOverDisbursed(): bool
    {
        return $this->sanctioned_amount !== null
            && $this->disbursed_amount !== null
            && $this->disbursed_amount > $this->sanctioned_amount;
    }

    public function scopeVisibleTo($query, User $user): void
    {
        // Super admin and admin with view_all_loans see everything
        if ($user->hasPermission('view_all_loans')) {
            return;
        }

        $query->where(function ($q) use ($user) {
            // Own loans (created or assigned as advisor) — always.
            $q->where('created_by', $user->id)
                ->orWhere('assigned_advisor', $user->id);

            // Stage-level visibility is for the operational roles that actually work
            // stages (advisors, bank/office employees). BM/BDH deliberately do NOT get
            // it — they see their own loans + everything in their branch, not a loan
            // outside their branch just because they're assigned one stage of it.
            if ($user->hasAnyRole(['loan_advisor', 'bank_employee', 'office_employee'])) {
                $q->orWhereHas('stageAssignments', fn ($sq) => $sq->where('assigned_to', $user->id));
            }

            // Branch managers and BDHs can see all loans in their branches
            if ($user->hasRole('branch_manager') || $user->hasRole('bdh')) {
                $branchIds = $user->branches()->pluck('branches.id')->toArray();
                if ($branchIds) {
                    $q->orWhereIn('branch_id', $branchIds);
                }
            }

            // Bank/office employees also see loans they've transferred from (stage_transfers history)
            if ($user->hasRole('bank_employee') || $user->hasRole('office_employee')) {
                $q->orWhereHas('stageTransfers', fn ($sq) => $sq->where('transferred_from', $user->id)->orWhere('transferred_to', $user->id));
            }

            // Connectors see (read-only) the loans created from their own quotations
            // (quotation ownership is tracked by user_id).
            if ($user->hasRole('connector')) {
                $q->orWhereHas('quotation', fn ($sq) => $sq->where('user_id', $user->id));
            }
        });
    }

    // Helpers

    private function formatIndianNumber($num): string
    {
        $num = (int) $num;
        if ($num < 1000) {
            return (string) $num;
        }

        $lastThree = $num % 1000;
        $remaining = (int) ($num / 1000);
        $result = '';

        if ($remaining > 0) {
            $remainStr = (string) $remaining;
            $len = strlen($remainStr);
            $groups = [];
            $i = $len;
            while ($i > 0) {
                $start = max(0, $i - 2);
                $groups[] = substr($remainStr, $start, $i - $start);
                $i = $start;
            }
            $result = implode(',', array_reverse($groups)).',';
        }

        $result .= str_pad($lastThree, 3, '0', STR_PAD_LEFT);

        return ltrim($result, '0,') ?: '0';
    }
}
