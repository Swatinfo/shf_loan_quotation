<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Models\Bank;
use App\Models\Branch;
use App\Models\LoanDetail;
use App\Models\ProductStage;
use App\Models\StageQuery;
use App\Models\User;
use App\Services\LoanDocumentService;
use App\Services\LoanStageService;
use App\Services\StageQueryService;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class LoanStageController extends Controller
{
    public function __construct(
        private LoanStageService $stageService,
        private StageQueryService $queryService,
    ) {}

    public function index(LoanDetail $loan)
    {
        $this->authorizeView($loan);

        $loan->load(['valuationDetails', 'location.parent', 'branch', 'product']);
        $stageAssignments = $this->stageService->getLoanStageStatus($loan);
        $mainStages = $stageAssignments->filter(fn ($sa) => ! $sa->is_parallel_stage && $sa->parent_stage_key === null);
        $subStages = $stageAssignments->filter(fn ($sa) => $sa->is_parallel_stage || $sa->parent_stage_key !== null);
        $progress = $loan->progress;
        $allActiveUsers = User::selectable()
            ->with(['employerBanks', 'locations', 'branches', 'roles'])
            ->orderBy('name')->get();
        $stageRoleEligibility = LoanStageService::getAllStageRoleEligibility();

        // Build skip-allowed map from product stage config
        $skipAllowed = [];
        if ($loan->product_id) {
            $productStages = ProductStage::where('product_id', $loan->product_id)
                ->with('stage')
                ->get();
            foreach ($productStages as $ps) {
                if ($ps->stage) {
                    $skipAllowed[$ps->stage->stage_key] = $ps->allow_skip;
                }
            }
        }

        // Docket-date override control: permission-gated, and only once the
        // Sanction stage is complete (when expected_docket_date first exists).
        $sanctionDone = $loan->stageAssignments()
            ->where('stage_key', 'sanction')
            ->where('status', 'completed')
            ->exists();
        $canEditDocketDate = auth()->user()->canEditDocketDate();

        $template = 'newtheme.loans.stages';

        return view($template, compact('loan', 'mainStages', 'subStages', 'progress', 'allActiveUsers', 'stageRoleEligibility', 'skipAllowed', 'sanctionDone', 'canEditDocketDate') + ['pageKey' => 'loans']);
    }

    /**
     * Rewind a loan to an earlier stage. Gated by the `reset_loan_stages`
     * permission (default roles: super_admin, admin, branch_manager, bdh).
     * Destructive: clears all following stages + dependent data.
     */
    public function resetStage(Request $request, LoanDetail $loan): JsonResponse
    {
        abort_unless(auth()->user()->canResetLoanStages(), 403, 'You are not permitted to reset loan stages.');

        $validated = $request->validate([
            'stage_key' => ['required', 'string', Rule::exists('stages', 'stage_key')->where(fn ($q) => $q->where('is_enabled', true))],
            'phase' => ['nullable', 'integer', 'min:1', 'max:4'],
            'variant' => ['nullable', 'in:escalated_bm,escalated_bdh,transferred_oe'],
        ]);

        // The loan must actually include the selected stage in its workflow.
        abort_unless(
            $loan->stageAssignments()->where('stage_key', $validated['stage_key'])->exists(),
            422,
            'This loan does not include the selected stage.'
        );

        $fromStage = $loan->current_stage;

        try {
            $log = $this->stageService->resetToStage(
                $loan,
                $validated['stage_key'],
                $validated['phase'] ?? null,
                $validated['variant'] ?? null,
            );
        } catch (\RuntimeException $e) {
            return response()->json(['error' => $e->getMessage()], 422);
        }

        ActivityLog::log('reset_loan_stage', $loan, [
            'loan_number' => $loan->loan_number,
            'from_stage' => $fromStage,
            'to_stage' => $validated['stage_key'],
            'phase' => $validated['phase'] ?? null,
            'variant' => $validated['variant'] ?? null,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Loan reset to '.$validated['stage_key'].'.',
            'redirect' => route('loans.stages', $loan),
            'log' => $log,
        ]);
    }

    public function updateStatus(Request $request, LoanDetail $loan, string $stageKey): JsonResponse
    {
        $validated = $request->validate([
            'status' => 'required|in:in_progress,completed,rejected,skipped',
        ]);

        if ($validated['status'] === 'skipped' && ! auth()->user()->hasPermission('skip_loan_stages')) {
            return response()->json(['error' => 'You do not have permission to skip stages'], 403);
        }

        // Docket phase 2: office employee clicks "Generate KFS" → complete docket directly
        // (KFS stage will be assigned to task owner via handleStageCompletion)

        // Block completion if required stage data is missing
        if ($validated['status'] === 'completed') {
            $assignment = $loan->stageAssignments()->where('stage_key', $stageKey)->first();
            if ($assignment) {
                // Check for unresolved queries
                if ($assignment->hasPendingQueries()) {
                    $pendingCount = $assignment->queries()->whereIn('status', ['pending', 'responded'])->count();

                    return response()->json(['error' => "Cannot complete — {$pendingCount} unresolved query/queries. Resolve all queries first."], 422);
                }

                // Check document collection separately
                if ($stageKey === 'document_collection') {
                    $docService = app(LoanDocumentService::class);
                    if (! $docService->allRequiredResolved($loan)) {
                        return response()->json(['error' => 'Cannot complete — not all required documents have been collected.'], 422);
                    }
                } elseif (in_array($stageKey, ['technical_valuation', 'property_valuation'])) {
                    // Valuation stages need valuation_details record
                    if (! $loan->valuationDetails()->where('valuation_type', 'property')->whereNotNull('final_valuation')->exists()) {
                        return response()->json(['error' => 'Cannot complete — fill the valuation form first.'], 422);
                    }
                } elseif ($stageKey === 'kfs') {
                    // The loan amount is editable at KFS — it must be a valid positive
                    // figure to complete (server-authoritative, even if the client
                    // skipped the amount-save step).
                    $amount = (int) $loan->loan_amount;
                    if ($amount < 1 || $amount > 1000000000000) {
                        return response()->json(['error' => 'Cannot complete — enter a valid loan amount first.'], 422);
                    }
                } elseif (! $this->isStageDataComplete($stageKey, $assignment)) {
                    $missingFields = $this->getFieldErrors($stageKey, $assignment->getNotesData());
                    if (! empty($missingFields)) {
                        return response()->json([
                            'error' => 'Please fill all required fields',
                            'field_errors' => $missingFields,
                        ], 422);
                    }

                    return response()->json(['error' => 'Cannot complete — required details not filled.'], 422);
                }
            }
        }

        try {
            $assignment = $this->stageService->updateStageStatus(
                $loan,
                $stageKey,
                $validated['status'],
                auth()->id()
            );

            $loan->refresh();
            $progress = $this->stageService->recalculateProgress($loan);

            return response()->json([
                'success' => true,
                'assignment' => [
                    'stage_key' => $assignment->stage_key,
                    'status' => $assignment->status,
                ],
                'current_stage' => $loan->current_stage,
                'progress' => [
                    'completed' => $progress->completed_stages,
                    'total' => $progress->total_stages,
                    'percentage' => $progress->overall_percentage,
                ],
            ]);
        } catch (\RuntimeException $e) {
            return response()->json(['error' => $e->getMessage()], 422);
        }
    }

    public function assign(Request $request, LoanDetail $loan, string $stageKey): JsonResponse
    {
        $validated = $request->validate([
            'user_id' => 'required|exists:users,id',
        ]);

        $assignment = $this->stageService->assignStage($loan, $stageKey, $validated['user_id']);

        return response()->json([
            'success' => true,
            'assigned_to' => $assignment->assignee?->name,
        ]);
    }

    public function skip(LoanDetail $loan, string $stageKey): JsonResponse
    {
        try {
            $this->stageService->skipStage($loan, $stageKey, auth()->id());
            $loan->refresh();

            return response()->json([
                'success' => true,
                'current_stage' => $loan->current_stage,
            ]);
        } catch (\RuntimeException $e) {
            return response()->json(['error' => $e->getMessage()], 422);
        }
    }

    public function transfer(Request $request, LoanDetail $loan, string $stageKey): JsonResponse
    {
        $validated = $request->validate([
            'user_id' => 'required|exists:users,id',
            'reason' => 'nullable|string|max:1000',
        ]);

        try {
            // Clear handover_date on OTC transfer so the new assignee fills it
            if ($stageKey === 'otc_clearance') {
                $otcAssignment = $loan->stageAssignments()->where('stage_key', 'otc_clearance')->first();
                if ($otcAssignment) {
                    $notes = $otcAssignment->getNotesData();
                    unset($notes['handover_date']);
                    $otcAssignment->update(['notes' => ! empty($notes) ? json_encode($notes) : null]);
                }
            }

            $assignment = $this->stageService->transferStage(
                $loan,
                $stageKey,
                (int) $validated['user_id'],
                $validated['reason'] ?? null
            );

            return response()->json([
                'success' => true,
                'assigned_to' => $assignment->assignee?->name,
            ]);
        } catch (\RuntimeException $e) {
            return response()->json(['error' => $e->getMessage()], 422);
        }
    }

    public function transferHistory(LoanDetail $loan)
    {
        // Connector-only readers may only see transfers of their own loans.
        $user = auth()->user();
        if (! $user->hasPermission('view_loans') && ! LoanDetail::visibleTo($user)->whereKey($loan->id)->exists()) {
            abort(403);
        }

        $transfers = $loan->stageTransfers()
            ->with(['fromUser', 'toUser', 'stageAssignment.stage'])
            ->latest('created_at')
            ->get();

        $template = 'newtheme.loans.transfers';

        return view($template, compact('loan', 'transfers') + ['pageKey' => 'loans']);
    }

    public function reject(Request $request, LoanDetail $loan, string $stageKey): JsonResponse
    {
        if (! auth()->user()->hasAnyRole(['super_admin', 'admin', 'branch_manager', 'bdh'])) {
            return response()->json(['error' => 'Only Branch Manager, BDH, or Admin can reject loans'], 403);
        }

        $validated = $request->validate([
            'reason' => 'required|string|max:2000',
        ]);

        $this->stageService->rejectLoan($loan, $stageKey, $validated['reason']);

        return response()->json(['success' => true, 'message' => 'Loan rejected']);
    }

    public function raiseQuery(Request $request, LoanDetail $loan, string $stageKey): JsonResponse
    {
        $validated = $request->validate([
            'query_text' => 'required|string|max:5000',
        ]);

        $assignment = $loan->stageAssignments()->where('stage_key', $stageKey)->firstOrFail();
        $query = $this->queryService->raiseQuery($assignment, $validated['query_text'], auth()->id());

        return response()->json(['success' => true, 'query' => $query->load('raisedByUser')]);
    }

    public function respondToQuery(Request $request, StageQuery $query): JsonResponse
    {
        $validated = $request->validate([
            'response_text' => 'required|string|max:5000',
        ]);

        $response = $this->queryService->respondToQuery($query, $validated['response_text'], auth()->id());

        return response()->json(['success' => true, 'response' => $response->load('respondedByUser')]);
    }

    public function resolveQuery(StageQuery $query): JsonResponse
    {
        if ($query->status === 'resolved') {
            return response()->json(['error' => 'This query is already resolved.'], 422);
        }

        // Resolvable by the raiser, the current assignee of the query's stage,
        // or admin/super_admin — regardless of pending/responded status.
        $user = auth()->user();
        $canResolve = $query->raised_by === $user->id
            || ($query->stageAssignment && $query->stageAssignment->assigned_to === $user->id)
            || $user->hasAnyRole(['super_admin', 'admin']);

        if (! $canResolve) {
            return response()->json(['error' => 'Only the query raiser, the current stage assignee, or an admin can resolve this query.'], 403);
        }

        $this->queryService->resolveQuery($query, $user->id);

        return response()->json(['success' => true]);
    }

    public function sanctionAction(Request $request, LoanDetail $loan): JsonResponse
    {
        $validated = $request->validate([
            'action' => 'required|in:send_for_sanction,sanction_generated',
            'transfer_to' => 'nullable|exists:users,id',
        ]);

        // An open query blocks any handoff/completion on this stage.
        if ($blocked = $this->queryBlock($loan, ['sanction'])) {
            return $blocked;
        }

        $assignment = $loan->stageAssignments()->where('stage_key', 'sanction')->firstOrFail();

        if ($validated['action'] === 'send_for_sanction') {
            $assignment->mergeNotesData([
                'sanction_phase' => '2',
                'sanction_original_assignee' => $assignment->assigned_to,
            ]);

            $transferTo = $validated['transfer_to'] ?? null;
            if (! $transferTo) {
                $phase2Role = $this->stageService->getLoanPhaseRole($loan, 'sanction', 1);
                $transferTo = $this->stageService->findUserForRole($phase2Role, $loan, 'sanction', 1);
            }

            if ($transferTo) {
                $this->stageService->transferStage($loan, 'sanction', (int) $transferTo, 'Sent for sanction letter generation');
            }

            return response()->json(['success' => true, 'message' => 'Sent for sanction letter generation']);
        }

        if ($validated['action'] === 'sanction_generated') {
            $assignment->mergeNotesData(['sanction_phase' => '3']);

            $transferTo = $validated['transfer_to'] ?? null;
            if (! $transferTo) {
                $phase3Role = $this->stageService->getLoanPhaseRole($loan, 'sanction', 2);
                $transferTo = $this->stageService->findUserForRole($phase3Role, $loan, 'sanction', 2);
            }

            if ($transferTo) {
                $this->stageService->transferStage($loan, 'sanction', (int) $transferTo, 'Sanction letter generated');
            }

            return response()->json(['success' => true, 'message' => 'Sanction letter marked as generated']);
        }

        return response()->json(['error' => 'Invalid action'], 422);
    }

    public function legalAction(Request $request, LoanDetail $loan): JsonResponse
    {
        $validated = $request->validate([
            'action' => 'required|in:send_to_bank,initiate_legal,complete_skip_bank',
            'suggested_legal_advisor' => 'nullable|string|max:255',
            'transfer_to' => 'nullable|exists:users,id',
        ]);

        // An open query blocks any handoff/completion on this stage.
        if ($blocked = $this->queryBlock($loan, ['legal_verification'])) {
            return $blocked;
        }

        $assignment = $loan->stageAssignments()->where('stage_key', 'legal_verification')->firstOrFail();

        if ($validated['action'] === 'complete_skip_bank') {
            if (! $this->canSkipLegalBank($loan)) {
                return response()->json(['error' => 'Only the loan owner / branch manager / BDH can skip bank verification.'], 403);
            }

            // Blocked by an open query on legal or its dependent ODV sub-stage.
            if ($blocked = $this->queryBlock($loan, ['legal_verification', 'original_document_verification'])) {
                return $blocked;
            }

            $assignment->mergeNotesData([
                'legal_phase' => 'completed_skip_bank',
                'legal_skipped_bank' => true,
                'legal_completed_by' => auth()->id(),
                'legal_completed_at' => now()->toDateTimeString(),
            ]);

            try {
                $this->stageService->updateStageStatus($loan, 'legal_verification', 'completed', auth()->id());
            } catch (\RuntimeException $e) {
                return response()->json(['error' => $e->getMessage()], 422);
            }

            ActivityLog::log('legal_completed_skip_bank', $assignment->fresh(), [
                'loan_number' => $loan->loan_number,
            ]);

            return response()->json(['success' => true, 'message' => 'Legal verification completed (bank-side skipped). Original Document Verification auto-completed.']);
        }

        if ($validated['action'] === 'send_to_bank') {
            $assignment->mergeNotesData([
                'legal_phase' => '2',
                'legal_original_assignee' => $assignment->assigned_to,
                'suggested_legal_advisor' => $validated['suggested_legal_advisor'] ?? '',
            ]);

            $transferTo = $validated['transfer_to'] ?? null;
            if (! $transferTo) {
                $phase2Role = $this->stageService->getLoanPhaseRole($loan, 'legal_verification', 1);
                $transferTo = $this->stageService->findUserForRole($phase2Role, $loan, 'legal_verification', 1);
            }

            if ($transferTo) {
                $this->stageService->transferStage($loan, 'legal_verification', (int) $transferTo, 'Sent for legal verification');
            }

            return response()->json(['success' => true, 'message' => 'Sent for legal verification']);
        }

        if ($validated['action'] === 'initiate_legal') {
            $assignment->mergeNotesData([
                'legal_phase' => '3',
                'confirmed_legal_advisor' => $validated['suggested_legal_advisor'] ?? $assignment->getNotesData()['suggested_legal_advisor'] ?? '',
            ]);

            $transferTo = $validated['transfer_to'] ?? null;
            if (! $transferTo) {
                $phase3Role = $this->stageService->getLoanPhaseRole($loan, 'legal_verification', 2);
                $transferTo = $this->stageService->findUserForRole($phase3Role, $loan, 'legal_verification', 2);
            }

            if ($transferTo) {
                $this->stageService->transferStage($loan, 'legal_verification', (int) $transferTo, 'Legal initiated, transferred back');
            }

            return response()->json(['success' => true, 'message' => 'Legal initiated, transferred to task owner']);
        }

        return response()->json(['error' => 'Invalid action'], 422);
    }

    public function technicalValuationAction(Request $request, LoanDetail $loan): JsonResponse
    {
        $validated = $request->validate([
            'action' => 'required|in:send_to_office',
            'transfer_to' => 'nullable|exists:users,id',
        ]);

        // An open query blocks any handoff on this stage.
        if ($blocked = $this->queryBlock($loan, ['technical_valuation'])) {
            return $blocked;
        }

        $assignment = $loan->stageAssignments()->where('stage_key', 'technical_valuation')->firstOrFail();

        $assignment->mergeNotesData([
            'tv_phase' => '2',
            'tv_original_assignee' => $assignment->assigned_to,
        ]);

        $transferTo = $validated['transfer_to'] ?? null;
        if (! $transferTo) {
            $phase2Role = $this->stageService->getLoanPhaseRole($loan, 'technical_valuation', 1);
            $transferTo = $this->stageService->findUserForRole($phase2Role, $loan, 'technical_valuation', 1);
        }

        if ($transferTo) {
            $this->stageService->transferStage($loan, 'technical_valuation', (int) $transferTo, 'Sent for technical valuation');
        }

        return response()->json(['success' => true, 'message' => 'Sent for technical valuation']);
    }

    public function esignAction(Request $request, LoanDetail $loan): JsonResponse
    {
        $validated = $request->validate([
            'action' => 'required|in:send_for_esign,esign_generated,esign_customer_done,esign_complete',
            'transfer_to' => 'nullable|exists:users,id',
        ]);

        // An open query blocks any handoff/completion on this stage.
        if ($blocked = $this->queryBlock($loan, ['esign'])) {
            return $blocked;
        }

        $assignment = $loan->stageAssignments()->where('stage_key', 'esign')->firstOrFail();

        // Phase 1 → 2
        if ($validated['action'] === 'send_for_esign') {
            $assignment->mergeNotesData([
                'esign_phase' => '2',
                'esign_original_assignee' => $assignment->assigned_to,
            ]);

            $transferTo = $validated['transfer_to'] ?? null;
            if (! $transferTo) {
                $phase2Role = $this->stageService->getLoanPhaseRole($loan, 'esign', 1);
                $transferTo = $this->stageService->findUserForRole($phase2Role, $loan, 'esign', 1);
            }

            if ($transferTo) {
                $this->stageService->transferStage($loan, 'esign', (int) $transferTo, 'Sent for E-Sign & eNACH generation');
            }

            return response()->json(['success' => true, 'message' => 'Sent for E-Sign & eNACH generation']);
        }

        // Phase 2 → 3
        if ($validated['action'] === 'esign_generated') {
            $assignment->mergeNotesData([
                'esign_phase' => '3',
                'esign_bank_employee' => $assignment->assigned_to,
            ]);

            $transferTo = $validated['transfer_to'] ?? null;
            if (! $transferTo) {
                $phase3Role = $this->stageService->getLoanPhaseRole($loan, 'esign', 2);
                $transferTo = $this->stageService->findUserForRole($phase3Role, $loan, 'esign', 2);
            }

            if ($transferTo) {
                $this->stageService->transferStage($loan, 'esign', (int) $transferTo, 'E-Sign docs generated, sent for customer completion');
            }

            return response()->json(['success' => true, 'message' => 'Sent to task owner for customer completion']);
        }

        // Phase 3 → 4
        if ($validated['action'] === 'esign_customer_done') {
            $assignment->mergeNotesData(['esign_phase' => '4']);

            $transferTo = $validated['transfer_to'] ?? null;
            if (! $transferTo) {
                $phase4Role = $this->stageService->getLoanPhaseRole($loan, 'esign', 3);
                $transferTo = $this->stageService->findUserForRole($phase4Role, $loan, 'esign', 3);
            }

            if ($transferTo) {
                $this->stageService->transferStage($loan, 'esign', (int) $transferTo, 'E-Sign completed with customer, returned for confirmation');
            }

            return response()->json(['success' => true, 'message' => 'Returned for final confirmation']);
        }

        // Phase 4: Bank employee confirms → complete stage
        if ($validated['action'] === 'esign_complete') {
            if ($blocked = $this->queryBlock($loan, ['esign'])) {
                return $blocked;
            }
            try {
                $this->stageService->updateStageStatus($loan, 'esign', 'completed', auth()->id());
            } catch (\RuntimeException $e) {
                return response()->json(['error' => $e->getMessage()], 422);
            }
            $loan->refresh();
            $progress = $this->stageService->recalculateProgress($loan);

            return response()->json([
                'success' => true,
                'message' => 'E-Sign & eNACH completed',
                'assignment' => ['stage_key' => 'esign', 'status' => 'completed'],
                'current_stage' => $loan->current_stage,
                'progress' => ['completed' => $progress->completed_stages, 'total' => $progress->total_stages, 'percentage' => $progress->overall_percentage],
            ]);
        }

        return response()->json(['error' => 'Invalid action'], 422);
    }

    public function docketAction(Request $request, LoanDetail $loan): JsonResponse
    {
        $validated = $request->validate([
            'action' => 'required|in:send_to_office',
            'transfer_to' => 'nullable|exists:users,id',
        ]);

        // An open query blocks any handoff on this stage.
        if ($blocked = $this->queryBlock($loan, ['docket'])) {
            return $blocked;
        }

        $assignment = $loan->stageAssignments()->where('stage_key', 'docket')->firstOrFail();

        $assignment->mergeNotesData([
            'docket_phase' => '2',
            'docket_original_assignee' => $assignment->assigned_to,
        ]);

        $transferTo = $validated['transfer_to'] ?? null;
        if (! $transferTo) {
            $phase2Role = $this->stageService->getLoanPhaseRole($loan, 'docket', 1);
            $transferTo = $this->stageService->findUserForRole($phase2Role, $loan, 'docket', 1);
        }

        if ($transferTo) {
            $this->stageService->transferStage($loan, 'docket', (int) $transferTo, 'Sent for docket review');
        }

        return response()->json(['success' => true, 'message' => 'Sent for docket review']);
    }

    public function ratePfAction(Request $request, LoanDetail $loan): JsonResponse
    {
        $validated = $request->validate([
            'action' => 'required|in:send_to_bank,return_to_owner,complete',
            'transfer_to' => 'nullable|exists:users,id',
        ]);

        // An open query blocks any handoff/completion on this stage (checked before
        // field validation so the query is the primary gate).
        if ($blocked = $this->queryBlock($loan, ['rate_pf'])) {
            return $blocked;
        }

        $assignment = $loan->stageAssignments()->where('stage_key', 'rate_pf')->firstOrFail();
        $notesData = $assignment->getNotesData();

        $requiredFields = [
            'interest_rate' => 'Interest Rate',
            'repo_rate' => 'Repo Rate',
            'bank_rate' => 'Bank Margin',
            'rate_offered_date' => 'Rate Offered Date',
            'rate_valid_until' => 'Valid Until',
            'processing_fee_type' => 'PF Type',
            'processing_fee' => 'Processing Fee',
            'gst_percent' => 'GST %',
            'admin_charges' => 'Admin Charges',
            'admin_charges_gst_percent' => 'Admin GST %',
        ];

        $fieldErrors = [];
        foreach ($requiredFields as $field => $label) {
            if (! isset($notesData[$field]) || $notesData[$field] === '' || $notesData[$field] === null) {
                $fieldErrors[$field] = $label.' is required';
            }
        }
        if (! empty($fieldErrors)) {
            return response()->json([
                'error' => 'Please fill all required fields',
                'field_errors' => $fieldErrors,
            ], 422);
        }

        if ($validated['action'] === 'send_to_bank') {
            $originalValues = [];
            foreach ($requiredFields as $field => $label) {
                $originalValues[$field] = $notesData[$field] ?? '';
            }
            // Include calculated/display fields in snapshot
            foreach (['processing_fee_amount', 'pf_gst_amount', 'total_pf', 'admin_charges_gst_amount', 'total_admin_charges', 'bank_reference'] as $extra) {
                $originalValues[$extra] = $notesData[$extra] ?? '';
            }
            $originalValues['special_conditions'] = $notesData['special_conditions'] ?? '';

            $assignment->mergeNotesData([
                'rate_pf_phase' => '2',
                'rate_pf_original_assignee' => $assignment->assigned_to,
                'original_values' => $originalValues,
            ]);

            $transferTo = $validated['transfer_to'] ?? null;
            if (! $transferTo) {
                $phase2Role = $this->stageService->getLoanPhaseRole($loan, 'rate_pf', 1);
                $transferTo = $this->stageService->findUserForRole($phase2Role, $loan, 'rate_pf', 1);
            }

            if ($transferTo) {
                $this->stageService->transferStage($loan, 'rate_pf', (int) $transferTo, 'Sent for bank rate review');
            }

            return response()->json(['success' => true, 'message' => 'Sent for rate review']);
        }

        if ($validated['action'] === 'return_to_owner') {
            $assignment->mergeNotesData(['rate_pf_phase' => '3']);

            $transferTo = $validated['transfer_to'] ?? null;
            if (! $transferTo) {
                $phase3Role = $this->stageService->getLoanPhaseRole($loan, 'rate_pf', 2);
                $transferTo = $this->stageService->findUserForRole($phase3Role, $loan, 'rate_pf', 2);
            }

            if ($transferTo) {
                $this->stageService->transferStage($loan, 'rate_pf', (int) $transferTo, 'Bank reviewed rate details, returned');
            }

            return response()->json(['success' => true, 'message' => 'Returned to task owner']);
        }

        if ($validated['action'] === 'complete') {
            if ($blocked = $this->queryBlock($loan, ['rate_pf'])) {
                return $blocked;
            }
            try {
                $this->stageService->updateStageStatus($loan, 'rate_pf', 'completed', auth()->id());
            } catch (\RuntimeException $e) {
                return response()->json(['error' => $e->getMessage()], 422);
            }

            return response()->json(['success' => true, 'message' => 'Rate & PF completed']);
        }

        return response()->json(['error' => 'Invalid action'], 422);
    }

    /**
     * If any of the given stages has an unresolved query (pending/responded),
     * return a 422 JSON response to block the action; otherwise null. Both
     * completing AND transferring a stage are blocked until the query is resolved.
     */
    private function queryBlock(LoanDetail $loan, array $stageKeys): ?JsonResponse
    {
        foreach ($stageKeys as $key) {
            $assignment = $loan->stageAssignments()->where('stage_key', $key)->first();
            if ($assignment && $assignment->hasPendingQueries()) {
                return response()->json([
                    'error' => 'An open query is blocking this stage. Resolve it before continuing.',
                ], 422);
            }
        }

        return null;
    }

    public function saveNotes(Request $request, LoanDetail $loan, string $stageKey): JsonResponse
    {
        $validated = $request->validate([
            'notes_data' => 'required|array',
        ]);

        $notesData = $validated['notes_data'];

        $assignment = $loan->stageAssignments()->where('stage_key', $stageKey)->firstOrFail();

        // DME is locked once the Application Number sub-stage is complete — only
        // the dedicated change-DME action (super_admin/admin/bdh) may alter it
        // afterwards. Strip any attempt to change it through the stage form.
        if ($stageKey === 'app_number' && $assignment->status === 'completed') {
            unset($notesData['dme_user_id']);
        }

        // Validate required fields only for non-completed stages
        // Merge with stored notes so phase-dependent validation has full context
        if ($assignment->status !== 'completed') {
            $fieldErrors = $this->getFieldErrors($stageKey, array_merge($assignment->getNotesData(), $notesData));
            if (! empty($fieldErrors)) {
                $messages = array_values($fieldErrors);

                return response()->json([
                    'error' => implode(', ', $messages),
                    'field_errors' => $fieldErrors,
                ], 422);
            }
        }

        // Docket: EMI amount must not exceed sanctioned amount (amount/rate/tenure/EMI now captured at docket login)
        if ($stageKey === 'docket' && isset($notesData['emi_amount'], $notesData['sanctioned_amount'])) {
            $emiAmount = (float) $notesData['emi_amount'];
            $sanctionedAmount = (float) $notesData['sanctioned_amount'];
            if ($emiAmount > $sanctionedAmount) {
                return response()->json([
                    'error' => 'EMI amount cannot exceed sanctioned amount',
                    'field_errors' => ['emi_amount' => 'EMI amount (₹ '.inr($emiAmount).') exceeds sanctioned amount (₹ '.inr($sanctionedAmount).')'],
                ], 422);
            }
        }

        $assignment->mergeNotesData($notesData);

        // Sync specific fields to loan_details
        if ($stageKey === 'app_number' && ! empty($notesData['application_number'])) {
            $loan->update(['application_number' => $notesData['application_number']]);
        }
        // Mirror the DME to the loan column (single source of truth, queryable +
        // used by the change-DME action). Only while the sub-stage is open.
        if ($stageKey === 'app_number' && $assignment->status !== 'completed' && ! empty($notesData['dme_user_id'])) {
            $loan->update(['dme_user_id' => (int) $notesData['dme_user_id']]);
        }

        // Mirror the sanctioned amount to its dedicated loan column (queryable, used
        // by listings). Captured at docket login; legacy loans use the sanction stage.
        // Docket always wins — only let the sanction stage fill an empty column.
        if (isset($notesData['sanctioned_amount']) && is_numeric($notesData['sanctioned_amount'])) {
            if ($stageKey === 'docket') {
                $loan->update(['sanctioned_amount' => (int) $notesData['sanctioned_amount']]);
            } elseif ($stageKey === 'sanction' && $loan->sanctioned_amount === null) {
                $loan->update(['sanctioned_amount' => (int) $notesData['sanctioned_amount']]);
            }
        }

        // Calculate and store expected docket date when sanction details are saved
        if ($stageKey === 'sanction' && ! empty($notesData['sanction_date'])) {
            $appNumberAssignment = $loan->stageAssignments()->where('stage_key', 'app_number')->first();
            $appNotes = $appNumberAssignment ? $appNumberAssignment->getNotesData() : [];
            $docketOffset = $appNotes['docket_days_offset'] ?? null;

            if ($docketOffset && $docketOffset !== '0') {
                $sanctionDateObj = Carbon::createFromFormat('d/m/Y', $notesData['sanction_date']);
                $loan->update(['due_date' => $sanctionDateObj->copy()->addDays((int) $docketOffset)->toDateString()]);
            } elseif ($docketOffset === '0' && ! empty($appNotes['custom_docket_date'])) {
                $loan->update(['due_date' => Carbon::createFromFormat('d/m/Y', $appNotes['custom_docket_date'])->toDateString()]);
            }
        }

        // Refresh assignment after notes merge
        $assignment->refresh();

        // Auto-complete if stage criteria met (for pending/in_progress stages).
        // Skipped while an open query blocks the stage — notes still save, the
        // stage waits for resolution (no error thrown).
        $stageAdvanced = false;
        $stageReverted = false;
        if (in_array($assignment->status, ['pending', 'in_progress']) && ! $assignment->hasPendingQueries() && $this->isStageDataComplete($stageKey, $assignment)) {
            if ($assignment->status === 'pending') {
                $this->stageService->updateStageStatus($loan, $stageKey, 'in_progress', auth()->id());
            }
            $this->stageService->updateStageStatus($loan, $stageKey, 'completed', auth()->id());
            $stageAdvanced = true;
        }

        // Soft-revert: if a completed stage's edit makes it incomplete, revert status
        if ($assignment->status === 'completed' && ! $stageAdvanced) {
            $stageReverted = $this->stageService->revertStageIfIncomplete(
                $loan,
                $stageKey,
                $this->isStageDataComplete($stageKey, $assignment)
            );
        }

        return response()->json([
            'success' => true,
            'stage_advanced' => $stageAdvanced,
            'stage_reverted' => $stageReverted,
        ]);
    }

    /**
     * Required fields per stage — returns [field_name => "Label is required"] for missing fields.
     */
    private function getFieldErrors(string $stageKey, array $data): array
    {
        $errors = [];

        $rules = match ($stageKey) {
            'app_number' => array_merge(
                ['application_number' => 'Application Number', 'dme_user_id' => 'DME', 'docket_days_offset' => 'Docket Timeline'],
                ($data['docket_days_offset'] ?? '') === '0' ? ['custom_docket_date' => 'Custom Docket Date'] : []
            ),
            'bsm_osv' => [],
            'legal_verification' => [],
            'original_document_verification' => ['verification_date' => 'Verification Date'],
            'technical_valuation', 'property_valuation' => [], // validated via valuation_details table, not notes
            'rate_pf' => [],
            'sanction' => $this->getSanctionRequiredFields($data),
            'docket' => $this->getDocketRequiredFields($data),
            'kfs' => [],
            'esign' => [],
            'otc_clearance' => ['handover_date' => 'Handover Date'],
            default => [],
        };

        foreach ($rules as $field => $label) {
            if (! isset($data[$field]) || $data[$field] === '' || $data[$field] === null) {
                $errors[$field] = "{$label} is required";
            }
        }

        // A custom docket date (offset = 0) must be today or later — never in the past.
        if (
            $stageKey === 'app_number'
            && ($data['docket_days_offset'] ?? '') === '0'
            && ! empty($data['custom_docket_date'])
            && ! isset($errors['custom_docket_date'])
        ) {
            $custom = rescue(fn () => Carbon::createFromFormat('d/m/Y', $data['custom_docket_date']), null, false);
            if (! $custom || $custom->startOfDay()->lt(now()->startOfDay())) {
                $errors['custom_docket_date'] = 'Custom Docket Date must be today or later';
            }
        }

        return $errors;
    }

    /**
     * Rate & PF has role-gated sections: bank employee fills rate, task owner fills PF/charges.
     * Only validate required fields that belong to the submitted section.
     */
    /**
     * Sanction stage phase 3: task owner captures only the sanction date.
     * Loan financials (amount, rate, tenure, EMI) are now captured at docket login.
     */
    private function getSanctionRequiredFields(array $data): array
    {
        if (! array_key_exists('sanction_date', $data)) {
            return [];
        }

        return [
            'sanction_date' => 'Sanction Date',
        ];
    }

    /**
     * Docket stage phase 2: office employee captures login date AND the loan financials
     * (sanctioned amount, sanctioned rate, tenure in months, EMI amount) that were
     * previously collected at the sanction stage.
     */
    private function getDocketRequiredFields(array $data): array
    {
        if (($data['docket_phase'] ?? '') !== '2') {
            return [];
        }

        return [
            'login_date' => 'Login Date',
            'sanctioned_amount' => 'Sanctioned Amount',
            'sanctioned_rate' => 'Sanctioned Rate',
            'tenure_months' => 'Tenure (Months)',
            'emi_amount' => 'EMI Amount',
        ];
    }

    /**
     * BSM/OSV: validate form fields only in phase 3 or 4.
     */
    /**
     * Authority gate for the legal-verification "complete without sending to
     * bank" action. Allowed for: super_admin, the loan creator, the loan's
     * assigned advisor, or any branch_manager / bdh attached to the loan's
     * branch. Bank employees are explicitly NOT allowed here — they would
     * never see Phase 1 anyway, but the server-side check is the source of
     * truth.
     */
    private function canSkipLegalBank(LoanDetail $loan): bool
    {
        $user = auth()->user();
        if (! $user) {
            return false;
        }
        // super_admin / admin: global authority.
        if ($user->hasRole('super_admin') || $user->hasRole('admin')) {
            return true;
        }
        // Loan owner / assigned advisor: their own loan.
        if ($loan->created_by === $user->id || $loan->assigned_advisor === $user->id) {
            return true;
        }
        // Branch managers / BDH are branch-bound — EVEN when they hold the waive
        // permission (their authority is "of the branch", per permissions.md). This
        // check takes precedence over the generic waive bypass below.
        if ($user->hasAnyRole(['branch_manager', 'bdh'])) {
            return (bool) $loan->branch_id
                && $user->branches()->where('branches.id', $loan->branch_id)->exists();
        }
        // Any other waive-holder (e.g. a non-owner advisor, office staff) can
        // complete-without-bank regardless of assignee / phase.
        if ($user->hasPermission('waive_legal_verification')) {
            return true;
        }

        return false;
    }

    /**
     * Check if all required data is present in the assignment's notes for auto-completion.
     */
    private function isStageDataComplete(string $stageKey, $assignment): bool
    {
        $notesData = $assignment->getNotesData();

        return match ($stageKey) {
            'app_number' => ! empty($notesData['application_number'])
                && ! empty($notesData['dme_user_id'])
                && isset($notesData['docket_days_offset']) && $notesData['docket_days_offset'] !== ''
                && ($notesData['docket_days_offset'] !== '0' || ! empty($notesData['custom_docket_date'])),
            'bsm_osv' => true,
            'legal_verification' => in_array($notesData['legal_phase'] ?? '', ['3', 'completed_skip_bank'], true),
            'original_document_verification' => ! empty($notesData['verification_date']),
            'technical_valuation', 'property_valuation' => false, // auto-completed by ValuationController, not saveNotes
            'rate_pf' => ($notesData['rate_pf_phase'] ?? '') === '3',
            'sanction' => ($notesData['sanction_phase'] ?? '') === '3'
                && ! empty($notesData['sanction_date']),
            'docket' => ($notesData['docket_phase'] ?? '') === '2'
                && ! empty($notesData['login_date'])
                && isset($notesData['sanctioned_amount']) && $notesData['sanctioned_amount'] !== ''
                && isset($notesData['sanctioned_rate']) && $notesData['sanctioned_rate'] !== ''
                && isset($notesData['tenure_months']) && $notesData['tenure_months'] !== ''
                && isset($notesData['emi_amount']) && $notesData['emi_amount'] !== '',
            'kfs' => true,
            'sanction_decision' => false, // completed via sanctionDecisionAction, not saveNotes
            'esign' => ($notesData['esign_phase'] ?? '') === '4',
            'otc_clearance' => ! empty($notesData['handover_date']),
            default => false,
        };
    }

    /**
     * Backward-compatible entry point for sanction_decision.
     */
    public function sanctionDecisionAction(Request $request, LoanDetail $loan): JsonResponse
    {
        return $this->decisionAction($request, $loan, 'sanction_decision');
    }

    /**
     * Escalation-ladder decision handler shared by sanction_decision and
     * technical_valuation. The escalation LEVEL is derived from the stage's
     * `escalation_history` (last to_role) — independent of the dynamic base
     * role assigned via product-stage config:
     *   - base : not yet escalated → current holder may Escalate to BM
     *   - bm   : escalated to branch_manager → BM may Escalate to BDH
     *   - bdh  : escalated to bdh → terminal
     * super_admin / admin bypass every level/role guard.
     *
     * sanction_decision supports `approve` (sanction the loan); technical_valuation
     * does NOT — its valuation form save is the approval (handled elsewhere).
     */
    public function decisionAction(Request $request, LoanDetail $loan, string $stageKey): JsonResponse
    {
        abort_unless(in_array($stageKey, ['sanction_decision', 'technical_valuation'], true), 404);

        $allowedActions = $stageKey === 'sanction_decision'
            ? 'approve,escalate_to_bm,escalate_to_bdh,reject'
            : 'escalate_to_bm,escalate_to_bdh,reject';

        $validated = $request->validate([
            'action' => 'required|in:'.$allowedActions,
            'decision_remarks' => 'nullable|string|max:2000',
            'rejection_reason' => 'nullable|string|max:2000',
            'transfer_to' => 'nullable|exists:users,id',
        ]);

        $assignment = $loan->stageAssignments()->where('stage_key', $stageKey)->firstOrFail();
        $notesData = $assignment->getNotesData();
        $user = auth()->user();
        $action = $validated['action'];
        $isAdmin = $user->hasAnyRole(['super_admin', 'admin']);

        // Escalation level from history (last to_role), independent of base role.
        $history = $notesData['escalation_history'] ?? [];
        $lastRole = $history ? ($history[count($history) - 1]['to_role'] ?? null) : null;
        $level = match ($lastRole) {
            'branch_manager' => 'bm',
            'bdh' => 'bdh',
            default => 'base',
        };

        // ── Approve (sanction_decision only) ──
        if ($action === 'approve') {
            // Guard BEFORE mutating: updateStageStatus() throws on unresolved
            // queries / invalid transitions, which previously left the loan
            // half-approved (is_sanctioned set, stage still in_progress) and
            // surfaced as a blank 500 in the UI.
            if ($assignment->hasPendingQueries()) {
                $pendingCount = $assignment->queries()->whereIn('status', ['pending', 'responded'])->count();

                return response()->json(['error' => "Cannot approve — {$pendingCount} unresolved query/queries on this stage. Resolve all queries first."], 422);
            }

            if ($assignment->status !== 'completed' && ! $assignment->canTransitionTo('completed')) {
                return response()->json(['error' => "Cannot approve — stage is '{$assignment->status}' and cannot be completed from that status."], 422);
            }

            $loan->update(['is_sanctioned' => true]);
            $assignment->mergeNotesData(['decision_action' => 'approved', 'decided_by' => $user->id]);
            $this->stageService->updateStageStatus($loan, $stageKey, 'completed', $user->id);
            $loan->refresh();
            $progress = $this->stageService->recalculateProgress($loan);

            return response()->json([
                'success' => true,
                'message' => 'Loan sanctioned successfully',
                'assignment' => ['stage_key' => $stageKey, 'status' => 'completed'],
                'current_stage' => $loan->current_stage,
                'progress' => ['completed' => $progress->completed_stages, 'total' => $progress->total_stages, 'percentage' => $progress->overall_percentage],
            ]);
        }

        // ── Escalate (requires remarks) ──
        if (in_array($action, ['escalate_to_bm', 'escalate_to_bdh'])) {
            if (empty($validated['decision_remarks'])) {
                return response()->json(['error' => 'Remarks are required for escalation'], 422);
            }

            // Escalation hands the stage to another user — blocked while a query is open.
            if ($assignment->hasPendingQueries()) {
                $pendingCount = $assignment->queries()->whereIn('status', ['pending', 'responded'])->count();

                return response()->json(['error' => "Cannot escalate — {$pendingCount} unresolved query/queries on this stage. Resolve all queries first."], 422);
            }

            // Level/role guards (admin bypasses).
            if (! $isAdmin) {
                if ($action === 'escalate_to_bm' && $level !== 'base') {
                    return response()->json(['error' => 'This task has already been escalated.'], 422);
                }
                if ($action === 'escalate_to_bdh' && ! ($level === 'bm' && $user->hasRole('branch_manager'))) {
                    return response()->json(['error' => 'Only a Branch Manager can escalate to BDH.'], 403);
                }
            }

            $targetRole = $action === 'escalate_to_bm' ? 'branch_manager' : 'bdh';
            $history[] = [
                'from_user_id' => $user->id,
                'from_user_name' => $user->name,
                'to_role' => $targetRole,
                'remarks' => $validated['decision_remarks'],
                'date' => now()->toDateTimeString(),
            ];
            $assignment->mergeNotesData([
                'escalation_history' => $history,
                'decision_remarks' => $validated['decision_remarks'],
            ]);

            $transferTo = $validated['transfer_to'] ?? null;
            if (! $transferTo) {
                $transferTo = User::where('is_active', true)
                    ->whereHas('roles', fn ($q) => $q->where('slug', $targetRole))
                    ->when($loan->branch_id, fn ($q) => $q->whereHas('branches', fn ($bq) => $bq->where('branches.id', $loan->branch_id)))
                    ->first()?->id;
            }
            if ($transferTo) {
                $this->stageService->transferStage($loan, $stageKey, (int) $transferTo, "Escalated to {$targetRole}: {$validated['decision_remarks']}");
            }

            $roleLabel = $action === 'escalate_to_bm' ? 'Branch Manager' : 'BDH';

            return response()->json(['success' => true, 'message' => "Escalated to {$roleLabel}"]);
        }

        // ── Reject (requires reason; bm/bdh level + BM/BDH, or admin) ──
        if ($action === 'reject') {
            if (empty($validated['rejection_reason']) || strlen($validated['rejection_reason']) < 10) {
                return response()->json(['error' => 'Rejection reason is required (minimum 10 characters)'], 422);
            }
            if (! $isAdmin && ! (in_array($level, ['bm', 'bdh'], true) && $user->hasAnyRole(['branch_manager', 'bdh']))) {
                return response()->json(['error' => 'Only Branch Manager or BDH can reject loans'], 403);
            }

            $assignment->mergeNotesData([
                'decision_action' => 'rejected',
                'rejection_reason' => $validated['rejection_reason'],
                'decided_by' => $user->id,
            ]);

            $this->stageService->rejectLoan($loan, $stageKey, $validated['rejection_reason'], $user->id);

            $loan->stageAssignments()
                ->whereIn('status', ['pending', 'in_progress'])
                ->where('stage_key', '!=', $stageKey)
                ->get()
                ->each(fn ($sa) => $sa->update([
                    'previous_status' => $sa->status,
                    'status' => 'rejected',
                    'completed_at' => now(),
                    'completed_by' => $user->id,
                ]));

            return response()->json(['success' => true, 'message' => 'Loan rejected']);
        }

        return response()->json(['error' => 'Invalid action'], 422);
    }

    public function eligibleUsers(Request $request, LoanDetail $loan, string $stageKey): JsonResponse
    {
        $role = $request->query('role');

        $query = User::selectable()->where('id', '!=', auth()->id())->with('roles')->select('id', 'name', 'email');

        if ($role) {
            $query->whereHas('roles', fn ($q) => $q->where('slug', $role));

            // Filter bank employees by loan's bank
            if ($role === 'bank_employee' && $loan->bank_id) {
                $query->where(function ($q) use ($loan) {
                    $q->whereHas('employerBanks', fn ($bq) => $bq->where('banks.id', $loan->bank_id))
                        ->orWhere('task_bank_id', $loan->bank_id);
                });
            }

            // Filter office employees by loan's bank
            if ($role === 'office_employee' && $loan->bank_id) {
                $query->whereHas('employerBanks', fn ($q) => $q->where('banks.id', $loan->bank_id));
            }

            // Filter branch-based roles by loan's branch
            if (in_array($role, ['branch_manager', 'bdh', 'loan_advisor']) && $loan->branch_id) {
                $query->whereHas('branches', fn ($q) => $q->where('branches.id', $loan->branch_id));
            }
        } else {
            // No role filter — resolve from loan's workflow config
            $resolvedRole = $this->stageService->getLoanStageRole($loan, $stageKey);
            if ($resolvedRole === 'task_owner') {
                $query->whereHas('roles', fn ($q) => $q->whereIn('slug', ['loan_advisor', 'branch_manager', 'bdh']));
            } else {
                $query->whereHas('roles', fn ($q) => $q->where('slug', $resolvedRole));
            }
            if (in_array($resolvedRole, ['bank_employee', 'office_employee']) && $loan->bank_id) {
                $query->whereHas('employerBanks', fn ($bq) => $bq->where('banks.id', $loan->bank_id));
            }
        }

        $users = $query->orderBy('name')->limit(50)->get();

        // Determine default user from loan's workflow config snapshot
        $resolvedRole = $role ?: $this->stageService->getLoanStageRole($loan, $stageKey);
        $defaultUserId = $this->stageService->findUserForRole($resolvedRole, $loan, $stageKey);

        // Ensure default is in the returned list
        if ($defaultUserId && ! $users->contains('id', $defaultUserId)) {
            $defaultUserId = null;
        }

        $payload = $users->map(fn ($u) => [
            'id' => $u->id,
            'name' => $u->name,
            'email' => $u->email,
            'role' => $u->workflow_role_label ?: $u->role_label,
        ]);

        return response()->json(['users' => $payload, 'default_user_id' => $defaultUserId]);
    }

    /**
     * Find a bank employee for the loan's bank.
     */
    private function findBankEmployee(LoanDetail $loan): ?int
    {
        // Try city-level default first
        $bank = Bank::find($loan->bank_id);
        if ($bank) {
            $cityId = $loan->branch_id ? Branch::find($loan->branch_id)?->location_id : null;
            $defaultBE = $bank->getDefaultEmployeeForCity($cityId);
            if ($defaultBE && User::where('id', $defaultBE)->where('is_active', true)->exists()) {
                return $defaultBE;
            }
        }

        // Fallback: any active bank employee for this bank
        $bankEmployee = User::whereHas('roles', fn ($q) => $q->where('slug', 'bank_employee'))
            ->where(function ($q) use ($loan) {
                $q->where('task_bank_id', $loan->bank_id)
                    ->orWhereHas('employerBanks', fn ($bq) => $bq->where('banks.id', $loan->bank_id));
            })
            ->where('is_active', true)
            ->first();

        return $bankEmployee?->id;
    }

    /**
     * Edit the loan amount at the KFS stage. The as-applied figure is preserved
     * on `original_loan_amount`; only the working `loan_amount` changes here.
     * Allowed for the KFS stage assignee or admin/super_admin, while KFS is
     * in_progress and the loan is active/on_hold.
     */
    public function updateKfsLoanAmount(Request $request, LoanDetail $loan): JsonResponse
    {
        $this->authorizeView($loan);

        $user = auth()->user();
        $kfs = $loan->stageAssignments()->where('stage_key', 'kfs')->first();

        if (! $kfs || $kfs->status !== 'in_progress') {
            return response()->json(['error' => 'The KFS stage is not active for this loan.'], 422);
        }

        if (! in_array($loan->status, [LoanDetail::STATUS_ACTIVE, LoanDetail::STATUS_ON_HOLD], true)) {
            return response()->json(['error' => 'Loan amount can only be changed while the loan is active or on hold.'], 422);
        }

        $isAdmin = $user->hasRole('super_admin') || $user->hasRole('admin');
        if (! $isAdmin && $kfs->assigned_to !== $user->id) {
            return response()->json(['error' => 'Only the KFS stage owner can change the loan amount.'], 403);
        }

        $validated = $request->validate([
            'loan_amount' => 'required|numeric|min:1|max:1000000000000',
        ]);

        $newAmount = (int) $validated['loan_amount'];
        $oldAmount = (int) $loan->loan_amount;

        $updates = ['loan_amount' => $newAmount];
        // Preserve the as-applied amount the first time it's edited (legacy loans
        // created before original_loan_amount existed have a null column).
        if ($loan->original_loan_amount === null) {
            $updates['original_loan_amount'] = $oldAmount;
        }
        $loan->update($updates);

        ActivityLog::log('change_loan_amount', $loan, [
            'loan_number' => $loan->loan_number,
            'stage_key' => 'kfs',
            'old_amount' => $oldAmount,
            'new_amount' => $newAmount,
        ]);

        $loan->refresh();

        return response()->json([
            'success' => true,
            'formatted_amount' => $loan->formatted_amount,
            'formatted_original_amount' => $loan->formatted_original_amount,
        ]);
    }

    private function authorizeView(LoanDetail $loan): void
    {
        $user = auth()->user();
        if ($user->hasPermission('view_all_loans')) {
            return;
        }
        if ($loan->created_by === $user->id || $loan->assigned_advisor === $user->id) {
            return;
        }
        if ($loan->stageAssignments()->where('assigned_to', $user->id)->exists()) {
            return;
        }
        if (($user->hasRole('branch_manager') || $user->hasRole('bdh')) && $loan->branch_id) {
            if ($user->branches()->where('branches.id', $loan->branch_id)->exists()) {
                return;
            }
        }
        // Connectors may view (read-only) the loans born from their own quotations.
        if ($user->hasRole('connector') && $loan->quotation_id
            && $loan->quotation()->where('user_id', $user->id)->exists()) {
            return;
        }
        abort(403);
    }
}
