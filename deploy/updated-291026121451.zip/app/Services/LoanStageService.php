<?php

namespace App\Services;

use App\Models\ActivityLog;
use App\Models\Bank;
use App\Models\BankStageConfig;
use App\Models\Branch;
use App\Models\LoanDetail;
use App\Models\LoanProgress;
use App\Models\Product;
use App\Models\ProductStage;
use App\Models\Stage;
use App\Models\StageAssignment;
use App\Models\StageQuery;
use App\Models\StageTransfer;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;

class LoanStageService
{
    /**
     * Get eligible roles for a stage from the database.
     */
    public static function getStageRoleEligibility(string $stageKey): array
    {
        $stage = Stage::where('stage_key', $stageKey)->first();

        return $stage?->default_role ?? [];
    }

    /**
     * Get all stage role eligibility as a map [stage_key => roles[]] from the database.
     */
    public static function getAllStageRoleEligibility(): array
    {
        return Stage::whereNotNull('default_role')
            ->pluck('default_role', 'stage_key')
            ->toArray();
    }

    // ── Bank-Wise Role Resolution ──

    /**
     * Resolve the assigned role for a stage (single-phase stages).
     * Priority: bank_stage_configs → stages.assigned_role
     */
    public function resolveStageRole(string $stageKey, ?int $bankId): string
    {
        if ($bankId) {
            $stage = Stage::where('stage_key', $stageKey)->first();
            if ($stage) {
                $bankConfig = BankStageConfig::where('bank_id', $bankId)
                    ->where('stage_id', $stage->id)
                    ->first();
                if ($bankConfig && $bankConfig->assigned_role) {
                    return $bankConfig->assigned_role;
                }
            }
        }

        $stage = $stage ?? Stage::where('stage_key', $stageKey)->first();

        return $stage?->assigned_role ?? 'task_owner';
    }

    /**
     * Resolve the role for a specific phase of a multi-phase stage.
     * Priority: bank_stage_configs.phase_roles → stages.sub_actions[].role
     */
    public function resolvePhaseRole(string $stageKey, int $phaseIndex, ?int $bankId): string
    {
        $stage = Stage::where('stage_key', $stageKey)->first();
        if (! $stage) {
            return 'task_owner';
        }

        // Check bank override
        if ($bankId) {
            $bankConfig = BankStageConfig::where('bank_id', $bankId)
                ->where('stage_id', $stage->id)
                ->first();
            if ($bankConfig && is_array($bankConfig->phase_roles) && isset($bankConfig->phase_roles[(string) $phaseIndex])) {
                return $bankConfig->phase_roles[(string) $phaseIndex];
            }
        }

        // Fall back to master sub_actions
        $subActions = $stage->sub_actions;
        if (is_array($subActions) && isset($subActions[$phaseIndex]['role'])) {
            return $subActions[$phaseIndex]['role'];
        }

        return 'task_owner';
    }

    /**
     * Build a complete workflow config snapshot for a loan.
     * Captures role + default_user_id for every stage and phase.
     */
    public function buildWorkflowSnapshot(?int $bankId, ?int $productId = null, ?int $branchId = null, ?int $locationId = null): array
    {
        $stages = Stage::where('is_enabled', true)->get();
        $config = [];

        // Pre-load bank configs for this bank
        $bankConfigs = [];
        if ($bankId) {
            $bankConfigs = BankStageConfig::where('bank_id', $bankId)
                ->get()
                ->keyBy('stage_id')
                ->toArray();
        }

        // Pre-load product stages for user resolution
        $productStages = [];
        if ($productId) {
            $productStages = ProductStage::where('product_id', $productId)
                ->with('branchUsers')
                ->get()
                ->keyBy('stage_id');
        }

        // Resolve branch location info
        $branch = $branchId ? Branch::with('location.parent')->find($branchId) : null;
        $cityId = $locationId ?? $branch?->location_id;
        $stateId = $branch?->location?->parent_id;

        foreach ($stages as $stage) {
            $bankConfig = $bankConfigs[$stage->id] ?? null;
            $ps = $productStages[$stage->id] ?? null;

            // Resolve stage-level role
            $stageRole = $bankConfig['assigned_role'] ?? $stage->assigned_role ?? 'task_owner';

            // Resolve stage-level default user
            $stageDefaultUser = $this->resolveDefaultUserFromProductStage($ps, $stageRole, $branchId, $cityId, $stateId);

            $stageConfig = [
                'role' => $stageRole,
                'default_user_id' => $stageDefaultUser,
            ];

            // Resolve phases for multi-phase stages
            $subActions = $stage->sub_actions;
            if (is_array($subActions) && count($subActions) > 0) {
                $phases = [];
                $bankPhaseRoles = is_array($bankConfig['phase_roles'] ?? null) ? $bankConfig['phase_roles'] : [];

                foreach ($subActions as $idx => $sa) {
                    $phaseRole = $bankPhaseRoles[(string) $idx] ?? $sa['role'] ?? 'task_owner';
                    $phaseDefaultUser = $this->resolveDefaultUserFromProductStage($ps, $phaseRole, $branchId, $cityId, $stateId, $idx);

                    $phases[(string) $idx] = [
                        'role' => $phaseRole,
                        'default_user_id' => $phaseDefaultUser,
                    ];
                }
                $stageConfig['phases'] = $phases;
            }

            $config[$stage->stage_key] = $stageConfig;
        }

        return $config;
    }

    /**
     * Get the role for a stage from a loan's frozen snapshot.
     * Falls back to live resolution for loans without snapshots.
     */
    public function getLoanStageRole(LoanDetail $loan, string $stageKey): string
    {
        $config = $loan->workflow_config;
        if ($config && isset($config[$stageKey]['role'])) {
            return $config[$stageKey]['role'];
        }

        return $this->resolveStageRole($stageKey, $loan->bank_id);
    }

    /**
     * Get the role for a specific phase from a loan's frozen snapshot.
     * Falls back to live resolution for loans without snapshots.
     */
    public function getLoanPhaseRole(LoanDetail $loan, string $stageKey, int $phaseIndex): string
    {
        $config = $loan->workflow_config;
        if ($config && isset($config[$stageKey]['phases'][(string) $phaseIndex]['role'])) {
            return $config[$stageKey]['phases'][(string) $phaseIndex]['role'];
        }

        return $this->resolvePhaseRole($stageKey, $phaseIndex, $loan->bank_id);
    }

    /**
     * Find the best user for a resolved role on a loan.
     * Priority: snapshot default_user → product stage user → bank/branch defaults → fallback.
     */
    public function findUserForRole(string $role, LoanDetail $loan, string $stageKey, ?int $phaseIndex = null): ?int
    {
        // 1. Check snapshot for frozen default user
        $config = $loan->workflow_config;
        if ($config && isset($config[$stageKey])) {
            $snapshotUserId = null;
            if ($phaseIndex !== null && isset($config[$stageKey]['phases'][(string) $phaseIndex])) {
                $snapshotUserId = $config[$stageKey]['phases'][(string) $phaseIndex]['default_user_id'] ?? null;
            } else {
                $snapshotUserId = $config[$stageKey]['default_user_id'] ?? null;
            }

            // If no stage-level user but has phases, find the first phase matching the requested role
            if (! $snapshotUserId && $phaseIndex === null && isset($config[$stageKey]['phases'])) {
                foreach ($config[$stageKey]['phases'] as $pIdx => $phaseData) {
                    if (($phaseData['role'] ?? '') === $role && ! empty($phaseData['default_user_id'])) {
                        $snapshotUserId = $phaseData['default_user_id'];
                        break;
                    }
                }
            }

            if ($snapshotUserId) {
                $user = User::where('id', $snapshotUserId)->where('is_active', true)->first();
                if ($user) {
                    return $user->id;
                }
            }
        }

        // 2. Resolve by role type
        if ($role === 'task_owner') {
            return $loan->assigned_advisor ?? $loan->created_by;
        }

        if ($role === 'bank_employee') {
            return $this->findBankEmployeeForLoan($loan, $stageKey, $phaseIndex);
        }

        if ($role === 'office_employee') {
            return $this->findOfficeEmployeeForLoan($loan, $stageKey);
        }

        return null;
    }

    /**
     * Find best bank employee for a loan.
     * Priority: product stage user → bank default for city → any BE for bank.
     */
    private function findBankEmployeeForLoan(LoanDetail $loan, string $stageKey, ?int $phaseIndex = null): ?int
    {
        // Product stage user (phase-aware)
        if ($loan->product_id) {
            $stage = $this->getStageByKey($stageKey);
            if ($stage) {
                $productStage = ProductStage::where('product_id', $loan->product_id)
                    ->where('stage_id', $stage->id)->first();
                if ($productStage) {
                    $branch = $loan->branch_id ? Branch::with('location.parent')->find($loan->branch_id) : null;
                    $cityId = $branch?->location_id;
                    $stateId = $branch?->location?->parent_id;
                    $userId = $productStage->getUserForLocation($loan->branch_id, $cityId, $stateId, $phaseIndex);
                    if ($userId && User::where('id', $userId)->where('is_active', true)->exists()) {
                        return $userId;
                    }
                }
            }
        }

        // Bank default employee for city
        if ($loan->bank_id) {
            $cityId = $loan->branch_id ? Branch::find($loan->branch_id)?->location_id : null;
            $bank = Bank::find($loan->bank_id);
            if ($bank) {
                $defaultBEId = $bank->getDefaultEmployeeForCity($cityId);
                if ($defaultBEId && User::where('id', $defaultBEId)->where('is_active', true)->exists()) {
                    return $defaultBEId;
                }
            }
        }

        // Any active bank employee for this bank
        if ($loan->bank_id) {
            $user = User::where('is_active', true)
                ->whereHas('employerBanks', fn ($q) => $q->where('banks.id', $loan->bank_id))
                ->first();
            if ($user) {
                return $user->id;
            }
        }

        return null;
    }

    /**
     * Resolve default user from product stage config for snapshot building.
     * Returns null for task_owner roles (resolved at runtime from loan).
     */
    private function resolveDefaultUserFromProductStage(?object $productStage, string $role, ?int $branchId, ?int $cityId, ?int $stateId, ?int $phaseIndex = null): ?int
    {
        if ($role === 'task_owner') {
            return null; // Always resolved from loan's advisor/creator at runtime
        }

        if (! $productStage) {
            return null;
        }

        // Check for phase-specific user assignment
        if ($phaseIndex !== null && $productStage->branchUsers) {
            $phaseUser = $productStage->branchUsers
                ->where('phase_index', $phaseIndex)
                ->where('is_default', true)
                ->when($branchId, fn ($c) => $c->where(fn ($u) => $u->branch_id === $branchId || $u->branch_id === null))
                ->first();
            if ($phaseUser) {
                return $phaseUser->user_id;
            }
        }

        // Fall back to stage-level user (phase_index = null)
        $userId = $productStage->getUserForLocation($branchId, $cityId, $stateId);

        return $userId;
    }

    // ── Query Methods (from Stage A) ──

    public function getOrderedStages(): Collection
    {
        return Stage::enabled()->mainStages()->get();
    }

    public function getStageByKey(string $key): ?Stage
    {
        return Stage::where('stage_key', $key)->first();
    }

    public function getSubStages(string $parentKey): Collection
    {
        return Stage::subStagesOf($parentKey)->get();
    }

    public function isParallelStage(string $key): bool
    {
        $stage = $this->getStageByKey($key);

        return $stage && ($stage->is_parallel || $stage->parent_stage_key !== null);
    }

    public function getMainStageKeys(): array
    {
        return Stage::enabled()->mainStages()->pluck('stage_key')->toArray();
    }

    // ── Initialization ──

    /**
     * Create stage assignments + loan progress for a new loan.
     * Uses only the base 14 stages (optional stages added via product_stages in Stage I).
     */
    public function initializeStages(LoanDetail $loan): void
    {
        $baseStageKeys = [
            'inquiry',
            'document_selection',
            'document_collection',
            'parallel_processing',
            'app_number',
            'bsm_osv',
            'legal_verification',
            'technical_valuation',
            'sanction_decision',
            'original_document_verification',
            'rate_pf',
            'sanction',
            'docket',
            'kfs',
            'esign',
            'disbursement',
            'otc_clearance',
        ];

        $stages = Stage::whereIn('stage_key', $baseStageKeys)
            ->where('is_enabled', true)
            ->get();

        // Respect product-level disables. If the loan has a product, filter
        // out any stage whose product_stages row is is_enabled = false. We
        // treat "no product_stages row" as enabled (safe default — matches
        // behaviour for legacy loans that pre-date product stage config).
        if ($loan->product_id) {
            $productStageStates = ProductStage::where('product_id', $loan->product_id)
                ->pluck('is_enabled', 'stage_id');

            $stages = $stages->filter(function (Stage $stage) use ($productStageStates) {
                // Missing row → keep the stage (default to enabled). Existing
                // row → honour the toggle.
                if (! $productStageStates->has($stage->id)) {
                    return true;
                }

                return (bool) $productStageStates[$stage->id];
            });
        }

        $mainCount = 0;

        foreach ($stages as $stage) {
            $isParallel = $stage->parent_stage_key !== null;

            StageAssignment::create([
                'loan_id' => $loan->id,
                'stage_key' => $stage->stage_key,
                'status' => 'pending',
                'priority' => 'normal',
                'is_parallel_stage' => $isParallel,
                'parent_stage_key' => $stage->parent_stage_key,
            ]);

            if (! $isParallel && $stage->parent_stage_key === null) {
                $mainCount++;
            }
        }

        LoanProgress::create([
            'loan_id' => $loan->id,
            'total_stages' => $mainCount,
            'completed_stages' => 0,
            'overall_percentage' => 0,
        ]);
    }

    /**
     * Auto-complete specific stages (used when converting from quotation).
     */
    public function autoCompleteStages(LoanDetail $loan, array $stageKeys): void
    {
        foreach ($stageKeys as $key) {
            $assignment = $loan->stageAssignments()->where('stage_key', $key)->first();
            if ($assignment) {
                $assignment->update([
                    'status' => 'completed',
                    'started_at' => now(),
                    'completed_at' => now(),
                    'completed_by' => auth()->id(),
                ]);
            }
        }

        $this->recalculateProgress($loan);
    }

    // ── Stage Transitions ──

    /**
     * Update a stage's status with validation and auto-advancement.
     */
    public function updateStageStatus(LoanDetail $loan, string $stageKey, string $newStatus, ?int $userId = null): StageAssignment
    {
        $assignment = $loan->stageAssignments()->where('stage_key', $stageKey)->firstOrFail();

        if ($assignment->status === $newStatus) {
            return $assignment;
        }

        if (! $assignment->canTransitionTo($newStatus)) {
            throw new \RuntimeException(
                "Cannot transition stage '{$stageKey}' from '{$assignment->status}' to '{$newStatus}'"
            );
        }

        // Block completion if pending queries
        if ($newStatus === 'completed' && $assignment->hasPendingQueries()) {
            throw new \RuntimeException(
                "Cannot complete stage '{$stageKey}' — there are unresolved queries."
            );
        }

        $oldStatus = $assignment->status;
        $updateData = ['status' => $newStatus];

        if ($newStatus === 'in_progress' && ! $assignment->started_at) {
            $updateData['started_at'] = now();
        }

        if (in_array($newStatus, ['completed', 'rejected', 'skipped'])) {
            $updateData['completed_at'] = now();
            $updateData['completed_by'] = $userId ?? auth()->id();
        }

        $assignment->update($updateData);

        ActivityLog::log('update_stage_status', $assignment, [
            'loan_number' => $loan->loan_number,
            'stage_key' => $stageKey,
            'old_status' => $oldStatus,
            'new_status' => $newStatus,
        ]);

        if (in_array($newStatus, ['completed', 'skipped'])) {
            $this->handleStageCompletion($loan, $stageKey);
            if ($newStatus === 'completed') {
                app(NotificationService::class)->notifyStageCompleted($loan, $stageKey);
            }
        }

        $this->recalculateProgress($loan);
        $loan->touch();

        return $assignment->fresh();
    }

    /**
     * Soft-revert a completed stage if its data is no longer complete.
     * Preserves all data (notes, assigned_to, timestamps) — only changes status.
     *
     * @param  bool  $isStillComplete  Whether the stage's completion criteria is still met
     * @return bool Whether a revert occurred
     */
    public function revertStageIfIncomplete(LoanDetail $loan, string $stageKey, bool $isStillComplete): bool
    {
        if ($isStillComplete) {
            return false;
        }

        $assignment = $loan->stageAssignments()->where('stage_key', $stageKey)->first();
        if (! $assignment || $assignment->status !== 'completed') {
            return false;
        }

        // Revert this stage: completed → in_progress
        $assignment->update([
            'previous_status' => 'completed',
            'status' => 'in_progress',
        ]);

        // Find and revert the next stage(s)
        $nextKey = $this->getNextStage($stageKey);
        while ($nextKey && ! $loan->stageAssignments()->where('stage_key', $nextKey)->exists()) {
            $nextKey = $this->getNextStage($nextKey);
        }

        if ($nextKey) {
            $nextAssignment = $loan->stageAssignments()->where('stage_key', $nextKey)->first();
            if ($nextAssignment && in_array($nextAssignment->status, ['in_progress', 'pending'])) {
                $nextAssignment->update([
                    'previous_status' => $nextAssignment->status,
                    'status' => 'pending',
                ]);

                // For parallel processing: also revert sub-stages to pending
                if ($nextKey === 'parallel_processing') {
                    $loan->stageAssignments()
                        ->where('parent_stage_key', 'parallel_processing')
                        ->whereIn('status', ['in_progress', 'pending'])
                        ->get()
                        ->each(function ($sub) {
                            $sub->update([
                                'previous_status' => $sub->status,
                                'status' => 'pending',
                            ]);
                        });
                }
            }

            // Update loan's current stage back
            $loan->update(['current_stage' => $stageKey]);
        }

        ActivityLog::log('stage_reverted', $assignment, [
            'loan_number' => $loan->loan_number,
            'stage_key' => $stageKey,
            'reason' => 'Stage data no longer meets completion criteria after edit',
        ]);

        $this->recalculateProgress($loan);
        $loan->touch();

        return true;
    }

    /**
     * Handle post-completion logic: auto-advance to next stage.
     */
    protected function handleStageCompletion(LoanDetail $loan, string $completedStageKey): void
    {
        $assignment = $loan->stageAssignments()->where('stage_key', $completedStageKey)->first();

        // Parallel sub-stage → sequential unlock: 4a → 4b → [4c, 4d, 4e in parallel]
        if ($assignment && ($assignment->is_parallel_stage || $assignment->parent_stage_key !== null)) {
            // When app_number completes, start ONLY bsm_osv
            if ($completedStageKey === 'app_number') {
                $this->startSingleParallelSubStage($loan, 'bsm_osv');
            }

            // When bsm_osv completes, start all remaining parallel sub-stages
            if ($completedStageKey === 'bsm_osv') {
                $this->startRemainingParallelSubStages($loan);

                if ($this->usesParallelRatePf()) {
                    $this->openRatePfInParallel($loan);
                }
            }

            // Legal verification gates original_document_verification.
            // - If legal was completed via the skip-bank path (notes carry
            //   `legal_skipped_bank=true`), auto-complete ODV with the same
            //   trigger recorded in its notes.
            // - Otherwise, start ODV normally so the operator can fill in
            //   verification_date + remarks.
            if ($completedStageKey === 'legal_verification') {
                $this->handleOriginalDocumentVerificationOnLegalComplete($loan, $assignment);
            }

            $this->checkParallelCompletion($loan);

            return;
        }
        // Feature-flagged: rate_pf runs in parallel with parallel_processing.
        // Sanction must wait for BOTH. When flag is off, fall through to default sequential advance.
        if ($completedStageKey === 'rate_pf' && $this->usesParallelRatePf()) {
            $this->advanceToSanctionIfReady($loan);

            return;
        }

        // Disbursement → otc_clearance is driven by DisbursementService::
        // syncDisbursementState (per-entry OTC). When the disbursement stage
        // completes it falls through to the normal sequential advance below,
        // which opens otc_clearance. Loan completion + per-entry OTC settlement
        // are owned by syncDisbursementState, NOT by this handler.

        // Sequential → advance to next and auto-start (skip stages not in this loan)
        $nextKey = $this->getNextStage($completedStageKey);
        while ($nextKey && ! $loan->stageAssignments()->where('stage_key', $nextKey)->exists()) {
            $nextKey = $this->getNextStage($nextKey);
        }
        if ($nextKey) {
            $loan->update(['current_stage' => $nextKey]);

            $this->assignNextStage($loan, $nextKey);

            // If entering parallel processing, auto-start parent + sub-stages
            if ($nextKey === 'parallel_processing') {
                $parentAssignment = $loan->stageAssignments()->where('stage_key', 'parallel_processing')->first();
                if ($parentAssignment) {
                    $parentAssignment->update(['status' => 'in_progress', 'started_at' => now()]);
                }
                $this->autoAssignParallelSubStages($loan);
            } else {
                // Auto-start the next stage
                $nextAssignment = $loan->stageAssignments()->where('stage_key', $nextKey)->first();
                if ($nextAssignment && $nextAssignment->status === 'pending') {
                    $nextAssignment->update(['status' => 'in_progress', 'started_at' => now()]);
                }
            }
        }

        // When the disbursement stage completes, re-run the disbursement/OTC
        // resolver so a loan whose tranches are already all OTC-settled finishes
        // immediately instead of waiting for a handover action that never comes
        // (the generic "complete stage" / reset-re-advance path never calls it).
        // Idempotent and guarded; a no-op while any cheque handover is outstanding.
        if ($completedStageKey === 'disbursement') {
            app(DisbursementService::class)->syncDisbursementState($loan->refresh());
        }

        // When sanction completes, calculate expected docket date from app_number notes
        if ($completedStageKey === 'sanction') {
            $appNumberAssignment = $loan->stageAssignments()->where('stage_key', 'app_number')->first();
            if ($appNumberAssignment) {
                $appNotes = $appNumberAssignment->getNotesData();
                $expectedDate = null;

                if (! empty($appNotes['custom_docket_date'])) {
                    $expectedDate = Carbon::createFromFormat('d/m/Y', $appNotes['custom_docket_date'])->toDateString();
                } elseif (! empty($appNotes['docket_days_offset'])) {
                    $expectedDate = now()->addDays((int) $appNotes['docket_days_offset'])->toDateString();
                }

                if ($expectedDate) {
                    $loan->update(['expected_docket_date' => $expectedDate]);
                }
            }
        }

        // otc_clearance completion no longer completes the loan here — that is
        // owned by DisbursementService::syncDisbursementState, which marks the
        // loan completed only once every tranche is OTC-settled.
    }

    /**
     * Get the next main stage key after the given one.
     */
    public function getNextStage(string $currentStageKey): ?string
    {
        $mainKeys = $this->getMainStageKeys();
        $currentIndex = array_search($currentStageKey, $mainKeys);

        if ($currentIndex === false || $currentIndex >= count($mainKeys) - 1) {
            return null;
        }

        return $mainKeys[$currentIndex + 1];
    }

    /**
     * Can the given stage be started?
     */
    public function canStartStage(LoanDetail $loan, string $stageKey): bool
    {
        $stage = $this->getStageByKey($stageKey);
        if (! $stage) {
            return false;
        }

        // Sub-stages can start when parent is current or in_progress
        if ($stage->parent_stage_key) {
            $parentAssignment = $loan->getStageAssignment($stage->parent_stage_key);
            $parentReady = $parentAssignment && in_array($parentAssignment->status, ['in_progress']);
            if (! $parentReady) {
                return false;
            }

            // original_document_verification has an extra dependency on
            // legal_verification — it can only start once legal completes
            // (handleStageCompletion auto-starts it then).
            if ($stageKey === 'original_document_verification') {
                $legal = $loan->getStageAssignment('legal_verification');

                return $legal && in_array($legal->status, ['completed', 'skipped']);
            }

            return true;
        }

        $mainKeys = $this->getMainStageKeys();
        $index = array_search($stageKey, $mainKeys);
        if ($index === 0) {
            return true;
        }

        // Rate & PF gating — branch on feature flag.
        if ($stageKey === 'rate_pf') {

            // Parallel mode (flag on): opens right after bsm_osv, alongside other parallel stages.
            // No is_sanctioned gate here — matches the freedom given to legal/technical/sanction_decision.
            if ($this->usesParallelRatePf()) {
                $bsm = $loan->getStageAssignment('bsm_osv');

                return $bsm && in_array($bsm->status, ['completed', 'skipped']);
            }

            // Legacy sequential mode: requires is_sanctioned + any parallel sub done.
            if (! $loan->is_sanctioned) {
                return false;
            }

            $anySubCompleted = $loan->stageAssignments()
                ->where('parent_stage_key', 'parallel_processing')
                ->where('status', 'completed')
                ->exists();

            return $anySubCompleted;
        }

        // Feature-flagged: sanction requires BOTH parallel_processing AND rate_pf complete.
        if ($stageKey === 'sanction' && $this->usesParallelRatePf()) {
            $parallel = $loan->getStageAssignment('parallel_processing');
            $ratePf = $loan->getStageAssignment('rate_pf');

            $parallelDone = $parallel && in_array($parallel->status, ['completed', 'skipped']);
            $ratePfDone = $ratePf && in_array($ratePf->status, ['completed', 'skipped']);

            return $parallelDone && $ratePfDone;
        }

        // Find the actual previous stage that exists in this loan's assignments
        $prevKey = null;
        for ($i = $index - 1; $i >= 0; $i--) {
            $candidate = $mainKeys[$i];
            if ($loan->getStageAssignment($candidate)) {
                $prevKey = $candidate;
                break;
            }
        }

        if (! $prevKey) {
            return false;
        }

        $prevAssignment = $loan->getStageAssignment($prevKey);
        $prevCompleted = $prevAssignment && in_array($prevAssignment->status, ['completed', 'skipped']);

        if (! $prevCompleted) {
            return false;
        }

        // If previous stage is rate_pf or parallel_processing, also require parallel_processing to be fully completed
        if (in_array($prevKey, ['rate_pf', 'parallel_processing'])) {
            $parallelAssignment = $loan->getStageAssignment('parallel_processing');

            return $parallelAssignment && in_array($parallelAssignment->status, ['completed', 'skipped']);
        }

        return true;
    }

    // ── Assignment ──

    public function assignStage(LoanDetail $loan, string $stageKey, int $userId): StageAssignment
    {
        $assignment = $loan->stageAssignments()->where('stage_key', $stageKey)->firstOrFail();
        $assignment->update(['assigned_to' => $userId]);

        ActivityLog::log('assign_stage', $assignment, [
            'loan_number' => $loan->loan_number,
            'stage_key' => $stageKey,
            'assigned_to_name' => User::find($userId)?->name,
        ]);

        if ($userId !== auth()->id()) {
            app(NotificationService::class)->notifyStageAssignment($loan, $stageKey, $userId);
        }

        return $assignment->fresh();
    }

    public function skipStage(LoanDetail $loan, string $stageKey, ?int $userId = null): StageAssignment
    {
        return $this->updateStageStatus($loan, $stageKey, 'skipped', $userId);
    }

    /**
     * Auto-assign a stage to the best-fit user.
     */
    public function autoAssignStage(LoanDetail $loan, string $stageKey): ?StageAssignment
    {
        // Parallel processing parent is just a label — never assign
        if ($stageKey === 'parallel_processing') {
            return $loan->stageAssignments()->where('stage_key', $stageKey)->first();
        }

        $assignment = $loan->stageAssignments()->where('stage_key', $stageKey)->first();
        if (! $assignment || $assignment->assigned_to) {
            return $assignment;
        }

        // Snapshot-first: use workflow_config's frozen role + default_user_id.
        // For task_owner stages this returns assigned_advisor ?? created_by,
        // which works uniformly for BDH / branch_manager / loan_advisor — the
        // legacy findBestAssignee path filtered BDH out because Stage.default_role
        // only listed branch_manager / loan_advisor.
        $userId = $this->resolveAutoAssignUser($loan, $stageKey);
        if (! $userId) {
            return $assignment;
        }

        $updateData = ['assigned_to' => $userId];
        // Auto-start the stage if it's still pending
        if ($assignment->status === 'pending') {
            $updateData['status'] = 'in_progress';
            $updateData['started_at'] = now();
        }
        $assignment->update($updateData);

        StageTransfer::create([
            'stage_assignment_id' => $assignment->id,
            'loan_id' => $loan->id,
            'stage_key' => $stageKey,
            'transferred_from' => auth()->id() ?? $loan->created_by,
            'transferred_to' => $userId,
            'reason' => 'Auto-assigned on stage advance',
            'transfer_type' => 'auto',
        ]);

        ActivityLog::log('auto_assign_stage', $assignment, [
            'loan_number' => $loan->loan_number,
            'stage_key' => $stageKey,
            'assigned_to_name' => User::find($userId)?->name,
        ]);

        if ($userId !== auth()->id()) {
            app(NotificationService::class)->notifyStageAssignment($loan, $stageKey, $userId);
        }

        return $assignment->fresh();
    }

    /**
     * Auto-assign parallel sub-stages. Only starts app_number first;
     * other sub-stages wait until app_number completes.
     */
    public function autoAssignParallelSubStages(LoanDetail $loan): void
    {
        $subStages = $loan->stageAssignments()
            ->where('parent_stage_key', 'parallel_processing')
            ->whereNull('assigned_to')
            ->get();

        foreach ($subStages as $assignment) {
            // Only auto-start app_number; others wait until app_number completes
            if ($assignment->stage_key !== 'app_number') {
                continue;
            }

            // Snapshot-first resolution — see resolveAutoAssignUser docblock.
            $userId = $this->resolveAutoAssignUser($loan, $assignment->stage_key);
            $updateData = ['status' => 'in_progress', 'started_at' => now()];
            if ($userId) {
                $updateData['assigned_to'] = $userId;
            }
            $assignment->update($updateData);
        }
    }

    /**
     * Snapshot-aware auto-assign: reads the loan's frozen workflow_config for
     * the stage's role + default_user_id, falls through to findUserForRole
     * (which handles task_owner / bank_employee / office_employee semantics),
     * and finally falls back to the legacy findBestAssignee for loans without
     * a snapshot. Keeps per-role uniformity — BDH, branch_manager, and
     * loan_advisor advisors all route through task_owner → advisor/creator.
     */
    private function resolveAutoAssignUser(LoanDetail $loan, string $stageKey): ?int
    {
        $role = $this->getLoanStageRole($loan, $stageKey);
        $userId = $this->findUserForRole($role, $loan, $stageKey);
        if ($userId) {
            return $userId;
        }

        // Legacy loans without workflow_config, or edge cases where role
        // resolution returned nothing — fall back to the original path.
        return $this->findBestAssignee(
            $stageKey,
            $loan->branch_id,
            $loan->bank_id,
            $loan->product_id,
            $loan->created_by,
            $loan->assigned_advisor,
        );
    }

    /**
     * Feature flag: open rate_pf in parallel with parallel sub-stages after bsm_osv.
     */
    private function usesParallelRatePf(): bool
    {
        return (bool) config('app.open_rate_pf_parallel');
    }

    /**
     * Start a single parallel sub-stage by key.
     */
    private function startSingleParallelSubStage(LoanDetail $loan, string $stageKey): void
    {
        $assignment = $loan->stageAssignments()
            ->where('stage_key', $stageKey)
            ->where('status', 'pending')
            ->first();

        if (! $assignment) {
            return;
        }

        $userId = $this->findBestAssignee($stageKey, $loan->branch_id, $loan->bank_id, $loan->product_id, $loan->created_by, $loan->assigned_advisor);
        $updateData = ['status' => 'in_progress', 'started_at' => now()];
        if ($userId) {
            $updateData['assigned_to'] = $userId;
        }
        $assignment->update($updateData);
    }

    /**
     * Start remaining parallel sub-stages after bsm_osv completes (4c, 4d, 4e).
     * Uses workflow config snapshot to determine roles and assignment.
     */
    /**
     * Reaction to legal_verification completion: either auto-complete ODV
     * (when legal was completed via the skip-bank path) or start it normally.
     *
     * Returns silently when the loan has no original_document_verification
     * assignment — keeps backwards-compat for in-flight loans created before
     * the stage existed.
     */
    private function handleOriginalDocumentVerificationOnLegalComplete(LoanDetail $loan, $legalAssignment): void
    {
        $odv = $loan->stageAssignments()
            ->where('stage_key', 'original_document_verification')
            ->first();

        if (! $odv || in_array($odv->status, ['completed', 'skipped'])) {
            return;
        }

        $legalNotes = $legalAssignment->getNotesData();
        $skippedBank = ! empty($legalNotes['legal_skipped_bank']);

        if ($skippedBank) {
            $odv->mergeNotesData([
                'auto_completed_reason' => 'legal_skipped_bank',
                'auto_completed_at' => now()->toDateTimeString(),
                'auto_completed_by' => auth()->id(),
            ]);
            // State machine forbids pending → completed; lift to in_progress
            // first so the canTransitionTo check passes.
            if ($odv->status === 'pending') {
                $this->updateStageStatus($loan, 'original_document_verification', 'in_progress', auth()->id());
            }
            $this->updateStageStatus($loan, 'original_document_verification', 'completed', auth()->id());

            ActivityLog::log('auto_complete_original_doc_verification', $odv->fresh(), [
                'loan_number' => $loan->loan_number,
                'reason' => 'legal_skipped_bank',
            ]);

            return;
        }

        // Normal path: open ODV for manual completion. Auto-assign to the
        // task owner (default_role = task_owner) so the operator who completed
        // legal can act on it next.
        if ($odv->status === 'pending') {
            $userId = $this->resolveAutoAssignUser($loan, 'original_document_verification');
            $update = ['status' => 'in_progress', 'started_at' => now()];
            if ($userId) {
                $update['assigned_to'] = $userId;
            }
            $odv->update($update);

            if ($userId && $userId !== auth()->id()) {
                app(NotificationService::class)->notifyStageAssignment($loan, 'original_document_verification', $userId);
            }
        }
    }

    private function startRemainingParallelSubStages(LoanDetail $loan): void
    {
        // original_document_verification waits for legal_verification to
        // complete — do NOT auto-start it alongside the other parallel
        // sub-stages when bsm_osv lands. handleStageCompletion('legal_verification')
        // is responsible for starting / auto-completing it.
        $pendingSubs = $loan->stageAssignments()
            ->where('parent_stage_key', 'parallel_processing')
            ->where('stage_key', '!=', 'original_document_verification')
            ->where('status', 'pending')
            ->get();

        foreach ($pendingSubs as $assignment) {
            $role = $this->getLoanStageRole($loan, $assignment->stage_key);
            $userId = $this->findUserForRole($role, $loan, $assignment->stage_key);

            $updateData = ['status' => 'in_progress', 'started_at' => now()];
            if ($userId) {
                $updateData['assigned_to'] = $userId;
            }
            $assignment->update($updateData);

            if ($userId) {
                StageTransfer::create([
                    'stage_assignment_id' => $assignment->id,
                    'loan_id' => $loan->id,
                    'stage_key' => $assignment->stage_key,
                    'transferred_from' => auth()->id() ?? $loan->created_by,
                    'transferred_to' => $userId,
                    'reason' => 'Auto-assigned to '.str_replace('_', ' ', $role),
                    'transfer_type' => 'auto',
                ]);
            }
        }
    }

    /**
     * Find the best office employee for a loan.
     * Priority: product stage config → branch default OE → any OE in branch → any active OE.
     */
    private function findOfficeEmployeeForLoan(LoanDetail $loan, string $stageKey = 'disbursement'): ?int
    {
        // Priority -1: Product stage config (bank-aware via product)
        if ($loan->product_id) {
            $stage = $this->getStageByKey($stageKey);
            if ($stage) {
                $productStage = ProductStage::where('product_id', $loan->product_id)
                    ->where('stage_id', $stage->id)->first();
                if ($productStage) {
                    $branch = $loan->branch_id ? Branch::with('location.parent')->find($loan->branch_id) : null;
                    $cityId = $branch?->location_id;
                    $stateId = $branch?->location?->parent_id;
                    $userId = $productStage->getUserForLocation($loan->branch_id, $cityId, $stateId);
                    if ($userId) {
                        $user = User::where('id', $userId)->where('is_active', true)->first();
                        if ($user) {
                            return $user->id;
                        }
                    }
                }
            }
        }

        // Priority 0b: Default office employee for the loan's branch
        if ($loan->branch_id) {
            $defaultOE = User::whereHas('branches', fn ($q) => $q->where('branches.id', $loan->branch_id)->where('user_branches.is_default_office_employee', true))
                ->where('is_active', true)
                ->first();
            if ($defaultOE) {
                return $defaultOE->id;
            }
        }

        // Fallback: any active office employee in the same branch
        if ($loan->branch_id) {
            $branchOE = User::whereHas('roles', fn ($q) => $q->where('slug', 'office_employee'))
                ->whereHas('branches', fn ($q) => $q->where('branches.id', $loan->branch_id))
                ->where('is_active', true)
                ->first();
            if ($branchOE) {
                return $branchOE->id;
            }
        }

        // Last resort: any active office employee
        $anyOE = User::whereHas('roles', fn ($q) => $q->where('slug', 'office_employee'))
            ->where('is_active', true)
            ->first();

        return $anyOE?->id;
    }

    /**
     * Find the best user for a stage.
     * Priority: product stage specific user → bank default employee → role+bank+branch match
     */
    public function findBestAssignee(string $stageKey, ?int $branchId, ?int $bankId, ?int $productId = null, ?int $loanCreatorId = null, ?int $advisorId = null): ?int
    {
        // Priority -1: Product stage has a location/branch-specific or default user assigned
        if ($productId) {
            $stage = $this->getStageByKey($stageKey);
            if ($stage) {
                $productStage = ProductStage::where('product_id', $productId)
                    ->where('stage_id', $stage->id)
                    ->first();
                if ($productStage) {
                    // Resolve location from branch
                    $branch = $branchId ? Branch::with('location.parent')->find($branchId) : null;
                    $cityId = $branch?->location_id;
                    $stateId = $branch?->location?->parent_id;

                    // Check branch → city → state → product default
                    $assignedUserId = $productStage->getUserForLocation($branchId, $cityId, $stateId);
                    if ($assignedUserId) {
                        $user = User::where('id', $assignedUserId)->where('is_active', true)->first();
                        if ($user) {
                            return $user->id;
                        }
                    }
                }
            }
        }

        $eligibleRoles = self::getStageRoleEligibility($stageKey);
        if (empty($eligibleRoles)) {
            return null;
        }

        // Priority 0a: Assigned advisor (for advisor-eligible stages)
        $advisorRoles = ['loan_advisor', 'branch_manager', 'bdh'];
        if ($advisorId && ! empty(array_intersect($eligibleRoles, $advisorRoles))) {
            $advisor = User::where('id', $advisorId)->where('is_active', true)->first();
            if ($advisor && $advisor->hasAnyRole($eligibleRoles)) {
                return $advisor->id;
            }
        }

        $baseQuery = User::where('is_active', true)->whereHas('roles', fn ($q) => $q->whereIn('slug', $eligibleRoles));
        $hasBankRole = in_array('bank_employee', $eligibleRoles);

        if ($hasBankRole && $bankId) {
            // Priority 0: Bank's default employee for this city
            $cityId = $branchId ? Branch::find($branchId)?->location_id : null;
            $bank = Bank::find($bankId);
            if ($bank) {
                $defaultBEId = $bank->getDefaultEmployeeForCity($cityId);
                if ($defaultBEId) {
                    $defaultEmp = User::where('id', $defaultBEId)->where('is_active', true)->first();
                    if ($defaultEmp) {
                        return $defaultEmp->id;
                    }
                }
            }

            // Priority 1: Bank employee from pivot table + in branch
            if ($branchId) {
                $user = User::where('is_active', true)
                    ->whereHas('employerBanks', fn ($q) => $q->where('banks.id', $bankId))
                    ->whereHas('branches', fn ($q) => $q->where('branches.id', $branchId))->first();
                if ($user) {
                    return $user->id;
                }
            }

            // Priority 2: Bank employee from pivot table (any branch)
            $user = User::where('is_active', true)
                ->whereHas('employerBanks', fn ($q) => $q->where('banks.id', $bankId))->first();
            if ($user) {
                return $user->id;
            }

            // Other eligible roles in branch
            $otherRoles = array_diff($eligibleRoles, ['bank_employee']);
            if ($branchId && ! empty($otherRoles)) {
                $user = User::where('is_active', true)
                    ->whereHas('roles', fn ($q) => $q->whereIn('slug', $otherRoles))
                    ->whereHas('branches', fn ($q) => $q->where('branches.id', $branchId))->first();
                if ($user) {
                    return $user->id;
                }
            }
        }

        // Priority 0b: Default office employee for the branch (from user_branches pivot)
        if (in_array('office_employee', $eligibleRoles) && $branchId) {
            $defaultOE = User::where('is_active', true)
                ->whereHas('roles', fn ($q) => $q->where('slug', 'office_employee'))
                ->whereHas('branches', fn ($q) => $q->where('branches.id', $branchId)->where('user_branches.is_default_office_employee', true))
                ->first();
            if ($defaultOE) {
                return $defaultOE->id;
            }
        }

        // Priority for loan_advisor/branch_manager: default to loan creator
        if ($loanCreatorId && (in_array('loan_advisor', $eligibleRoles) || in_array('branch_manager', $eligibleRoles) || in_array('bdh', $eligibleRoles))) {
            $creator = User::where('id', $loanCreatorId)->where('is_active', true)->first();
            if ($creator && $creator->hasAnyRole($eligibleRoles)) {
                return $creator->id;
            }
        }

        // Branch-based match
        if ($branchId) {
            $user = (clone $baseQuery)->whereHas('branches', fn ($q) => $q->where('branches.id', $branchId))->first();
            if ($user) {
                return $user->id;
            }
        }

        // Any matching role
        return $baseQuery->first()?->id;
    }

    // ── Transfer ──

    /**
     * Transfer a stage to another user with history tracking.
     */
    public function transferStage(LoanDetail $loan, string $stageKey, int $toUserId, ?string $reason = null): StageAssignment
    {
        $assignment = $loan->stageAssignments()->where('stage_key', $stageKey)->firstOrFail();

        // Block any handoff/transfer while an open query is pending on this stage —
        // the current assignee must resolve the query before moving it to another
        // user (mirrors the completion guard in updateStageStatus()).
        if ($assignment->hasPendingQueries()) {
            throw new \RuntimeException(
                "Cannot transfer stage '{$stageKey}' — there are unresolved queries. Resolve the open query first."
            );
        }

        $fromUserId = auth()->id();

        $assignment->update(['assigned_to' => $toUserId]);

        StageTransfer::create([
            'stage_assignment_id' => $assignment->id,
            'loan_id' => $loan->id,
            'stage_key' => $stageKey,
            'transferred_from' => $fromUserId,
            'transferred_to' => $toUserId,
            'reason' => $reason,
            'transfer_type' => 'manual',
        ]);

        // (A stage can only be transferred once its queries are resolved — the guard
        // above ensures no open query can follow a handoff.)

        ActivityLog::log('transfer_stage', $assignment, [
            'loan_number' => $loan->loan_number,
            'stage_key' => $stageKey,
            'from_user' => User::find($fromUserId)?->name,
            'to_user' => User::find($toUserId)?->name,
            'reason' => $reason,
        ]);

        if ($toUserId !== $fromUserId) {
            app(NotificationService::class)->notifyStageAssignment($loan, $stageKey, $toUserId);
        }

        $loan->touch();

        return $assignment->fresh();
    }

    // ── Config Propagation ──

    /**
     * Re-apply the current stage/task-owner config to every eligible loan.
     *
     * Eligible = any loan that is NOT completed (active, on_hold, rejected,
     * cancelled, and disbursed-but-open all qualify). For each loan the frozen
     * workflow_config snapshot is rebuilt from live config and its currently
     * in_progress stage owners are re-pointed — but ONLY when the stage is still
     * on its auto-resolved default. Manually-transferred stages are always
     * preserved (config never overwrites a hand-transfer). Rejected/cancelled
     * loans usually have no in_progress stages, so re-pointing is a no-op there,
     * but their snapshot is refreshed so a later reactivation uses current config.
     *
     * Shared by all three entry points: saveProductStages (product-scoped),
     * saveMasterStages (all eligible), and the "Sync Settings" button.
     *
     * @return array{loans_processed:int, stages_reassigned:int}
     */
    public function propagateConfigToEligibleLoans(?int $productId, ?int $bankId = null): array
    {
        $query = LoanDetail::query()
            ->where('status', '!=', LoanDetail::STATUS_COMPLETED);

        if ($productId) {
            $query->where('product_id', $productId);
        } elseif ($bankId) {
            $query->where('bank_id', $bankId);
        }

        $loansProcessed = 0;
        $stagesReassigned = 0;

        $query->with('stageAssignments')->chunkById(100, function ($loans) use (&$loansProcessed, &$stagesReassigned) {
            foreach ($loans as $loan) {
                $loansProcessed++;
                $stagesReassigned += $this->resyncLoanAssignments($loan);
            }
        });

        return ['loans_processed' => $loansProcessed, 'stages_reassigned' => $stagesReassigned];
    }

    /**
     * Manual "Sync Settings": loop every product and re-apply config to its
     * eligible loans, one product at a time.
     *
     * @return array{products:int, loans_processed:int, stages_reassigned:int}
     */
    public function propagateConfigToAllEligibleLoans(): array
    {
        $totals = ['products' => 0, 'loans_processed' => 0, 'stages_reassigned' => 0];

        Product::query()->each(function (Product $product) use (&$totals) {
            $result = $this->propagateConfigToEligibleLoans($product->id, null);
            $totals['products']++;
            $totals['loans_processed'] += $result['loans_processed'];
            $totals['stages_reassigned'] += $result['stages_reassigned'];
        });

        return $totals;
    }

    /**
     * Rebuild one loan's workflow_config snapshot and re-point its in_progress
     * stage owners that are still on the old auto-resolved default.
     *
     * @return int number of stages reassigned
     */
    private function resyncLoanAssignments(LoanDetail $loan): int
    {
        // 1. Resolve the OLD auto-assignee for each in_progress stage while the
        //    loan still carries the pre-change snapshot.
        $plan = [];
        foreach ($loan->stageAssignments as $assignment) {
            if ($assignment->status !== 'in_progress' || $assignment->stage_key === 'parallel_processing') {
                continue;
            }

            $phaseIndex = $this->resyncPhaseIndex($assignment);
            if ($phaseIndex === -1) {
                continue; // indeterminate phase — leave it alone
            }

            $normalizedPhase = $phaseIndex === null ? null : $phaseIndex;
            $role = $normalizedPhase !== null
                ? $this->getLoanPhaseRole($loan, $assignment->stage_key, $normalizedPhase)
                : $this->getLoanStageRole($loan, $assignment->stage_key);

            $oldUserId = $this->findUserForRole($role, $loan, $assignment->stage_key, $normalizedPhase);

            $plan[] = [
                'assignment' => $assignment,
                'phase' => $normalizedPhase,
                'old_user' => $oldUserId,
            ];
        }

        // 2. Rebuild + persist the fresh snapshot from live config.
        $loan->workflow_config = $this->buildWorkflowSnapshot(
            $loan->bank_id,
            $loan->product_id,
            $loan->branch_id,
            $loan->location_id
        );
        $loan->save();

        // 3. Re-point each stage still on its old default to the new default.
        $reassigned = 0;
        foreach ($plan as $entry) {
            /** @var StageAssignment $assignment */
            $assignment = $entry['assignment'];
            $oldUserId = $entry['old_user'];
            $currentUserId = $assignment->assigned_to;

            // Preserve manual transfers: only touch stages still on the old default.
            if (! $oldUserId || $currentUserId !== $oldUserId) {
                continue;
            }

            $phase = $entry['phase'];
            $role = $phase !== null
                ? $this->getLoanPhaseRole($loan, $assignment->stage_key, $phase)
                : $this->getLoanStageRole($loan, $assignment->stage_key);

            $newUserId = $this->findUserForRole($role, $loan, $assignment->stage_key, $phase);

            if (! $newUserId || $newUserId === $currentUserId) {
                continue;
            }

            $this->reassignForConfigChange($loan, $assignment, $newUserId);
            $reassigned++;
        }

        return $reassigned;
    }

    /**
     * Current phase index (0-based sub_actions index) for an in_progress stage.
     * Returns null for single-phase stages, or -1 when the phase is
     * indeterminate (non-numeric marker) and the stage should be skipped.
     */
    private function resyncPhaseIndex(StageAssignment $assignment): ?int
    {
        $noteKey = match ($assignment->stage_key) {
            'bsm_osv' => 'bsm_osv_phase',
            'legal_verification' => 'legal_phase',
            'rate_pf' => 'rate_pf_phase',
            'sanction' => 'sanction_phase',
            'docket' => 'docket_phase',
            'esign' => 'esign_phase',
            default => null,
        };

        if (! $noteKey) {
            return null; // single-phase stage
        }

        $phase = $assignment->getNotesData()[$noteKey] ?? null;
        if ($phase === null || $phase === '') {
            return 0; // entry phase
        }
        if (! is_numeric($phase)) {
            return -1; // e.g. 'completed_skip_bank' — skip
        }

        return max(0, (int) $phase - 1);
    }

    /**
     * Re-point a stage assignment to a new owner as a config-driven change:
     * writes the transfer ledger (real old → new), re-points open queries that
     * followed the outgoing owner, logs, and notifies the new owner.
     */
    private function reassignForConfigChange(LoanDetail $loan, StageAssignment $assignment, int $toUserId): void
    {
        $fromUserId = $assignment->assigned_to;
        $assignment->update(['assigned_to' => $toUserId]);

        StageTransfer::create([
            'stage_assignment_id' => $assignment->id,
            'loan_id' => $loan->id,
            'stage_key' => $assignment->stage_key,
            'transferred_from' => $fromUserId,
            'transferred_to' => $toUserId,
            'reason' => 'Config change: stage owner updated',
            'transfer_type' => 'auto',
        ]);

        if ($fromUserId) {
            StageQuery::where('loan_id', $loan->id)
                ->where('stage_key', $assignment->stage_key)
                ->whereIn('status', ['pending', 'responded'])
                ->where('assigned_to_user_id', $fromUserId)
                ->update(['assigned_to_user_id' => $toUserId]);
        }

        ActivityLog::log('config_reassign_stage', $assignment, [
            'loan_number' => $loan->loan_number,
            'stage_key' => $assignment->stage_key,
            'from_user' => User::find($fromUserId)?->name,
            'to_user' => User::find($toUserId)?->name,
        ]);

        try {
            app(NotificationService::class)->notifyStageAssignment($loan, $assignment->stage_key, $toUserId);
        } catch (\Throwable $e) {
            \Log::warning('Config reassign notify failed: '.$e->getMessage());
        }
    }

    // ── Rejection ──

    /**
     * Reject the entire loan from a stage.
     */
    public function rejectLoan(LoanDetail $loan, string $stageKey, string $reason, ?int $userId = null): LoanDetail
    {
        $userId = $userId ?? auth()->id();

        $loan->update([
            'status' => LoanDetail::STATUS_REJECTED,
            'rejected_at' => now(),
            'rejected_by' => $userId,
            'rejected_stage' => $stageKey,
            'rejection_reason' => $reason,
        ]);

        $assignment = $loan->stageAssignments()->where('stage_key', $stageKey)->first();
        if ($assignment) {
            $assignment->update([
                'previous_status' => $assignment->status,
                'status' => 'rejected',
                'completed_at' => now(),
                'completed_by' => $userId,
            ]);
        }

        ActivityLog::log('reject_loan', $loan, [
            'loan_number' => $loan->loan_number,
            'rejected_stage' => $stageKey,
            'reason' => $reason,
        ]);

        return $loan->fresh();
    }

    // ── Parallel Processing ──

    /**
     * Assign the next stage to the correct user based on workflow config snapshot.
     * Uses getLoanStageRole() to determine role, then findUserForRole() to find the user.
     */
    protected function assignNextStage(LoanDetail $loan, string $nextKey): void
    {
        $nextAssignment = $loan->stageAssignments()->where('stage_key', $nextKey)->first();
        if (! $nextAssignment || $nextAssignment->assigned_to) {
            return;
        }

        $role = $this->getLoanStageRole($loan, $nextKey);
        $userId = $this->findUserForRole($role, $loan, $nextKey);

        if ($userId) {
            $nextAssignment->update(['assigned_to' => $userId]);

            StageTransfer::create([
                'stage_assignment_id' => $nextAssignment->id,
                'loan_id' => $loan->id,
                'stage_key' => $nextKey,
                'transferred_from' => auth()->id() ?? $loan->created_by,
                'transferred_to' => $userId,
                'reason' => 'Auto-assigned to '.str_replace('_', ' ', $role),
                'transfer_type' => 'auto',
            ]);
        }
    }

    /**
     * Check if all parallel sub-stages are complete.
     */
    public function checkParallelCompletion(LoanDetail $loan): bool
    {
        $subStages = $loan->stageAssignments()->subStagesOf('parallel_processing')->get();

        $allDone = $subStages->every(fn ($sa) => in_array($sa->status, ['completed', 'skipped']));

        if ($allDone) {
            $parent = $loan->stageAssignments()->where('stage_key', 'parallel_processing')->first();
            if ($parent && $parent->status !== 'completed') {
                $parent->update([
                    'status' => 'completed',
                    'completed_at' => now(),
                    'completed_by' => auth()->id(),
                ]);
                if ($this->usesParallelRatePf()) {
                    // rate_pf runs in parallel — sanction opens only when BOTH are done.
                    $this->advanceToSanctionIfReady($loan);
                } else {
                    // Legacy sequential advance to next main stage (rate_pf, then sanction later).
                    $nextKey = $this->getNextStage('parallel_processing');
                    while ($nextKey && ! $loan->stageAssignments()->where('stage_key', $nextKey)->exists()) {
                        $nextKey = $this->getNextStage($nextKey);
                    }
                    if ($nextKey) {
                        $loan->update(['current_stage' => $nextKey]);
                        $this->assignNextStage($loan, $nextKey);

                        // Auto-start the next stage
                        $nextAssignment = $loan->stageAssignments()->where('stage_key', $nextKey)->first();
                        if ($nextAssignment && $nextAssignment->status === 'pending') {
                            $nextAssignment->update(['status' => 'in_progress', 'started_at' => now()]);
                        }
                    }
                }
            }

            $this->recalculateProgress($loan);

            return true;
        }

        return false;
    }

    /**
     * Open rate_pf alongside the parallel sub-stages (feature-flagged; called after bsm_osv).
     */
    public function openRatePfInParallel(LoanDetail $loan): void
    {
        $rateAssignment = $loan->stageAssignments()
            ->where('stage_key', 'rate_pf')
            ->where('status', 'pending')
            ->first();

        if (! $rateAssignment) {
            return;
        }

        $role = $this->getLoanStageRole($loan, 'rate_pf');
        $userId = $this->findUserForRole($role, $loan, 'rate_pf');

        $updateData = ['status' => 'in_progress', 'started_at' => now()];
        if ($userId) {
            $updateData['assigned_to'] = $userId;
        }
        $rateAssignment->update($updateData);

        if ($userId) {
            StageTransfer::create([
                'stage_assignment_id' => $rateAssignment->id,
                'loan_id' => $loan->id,
                'stage_key' => 'rate_pf',
                'transferred_from' => auth()->id() ?? $loan->created_by,
                'transferred_to' => $userId,
                'reason' => 'Auto-assigned to '.str_replace('_', ' ', $role).' (parallel with sub-stages)',
                'transfer_type' => 'auto',
            ]);
        }
    }

    /**
     * Advance to sanction only when BOTH parallel_processing AND rate_pf are complete.
     * Only used when open_rate_pf_parallel feature flag is on.
     */
    public function advanceToSanctionIfReady(LoanDetail $loan): void
    {
        $parallel = $loan->getStageAssignment('parallel_processing');
        $ratePf = $loan->getStageAssignment('rate_pf');

        $parallelDone = $parallel && in_array($parallel->status, ['completed', 'skipped']);
        $ratePfDone = $ratePf && in_array($ratePf->status, ['completed', 'skipped']);

        if (! $parallelDone || ! $ratePfDone) {
            return;
        }

        $sanction = $loan->stageAssignments()->where('stage_key', 'sanction')->first();
        if (! $sanction || $sanction->status !== 'pending') {
            return;
        }

        $loan->update(['current_stage' => 'sanction']);
        $this->assignNextStage($loan, 'sanction');

        $sanction->refresh();
        if ($sanction->status === 'pending') {
            $sanction->update(['status' => 'in_progress', 'started_at' => now()]);
        }
    }

    public function getParallelSubStages(LoanDetail $loan): Collection
    {
        return $loan->stageAssignments()
            ->subStagesOf('parallel_processing')
            ->with(['stage', 'assignee', 'activeQueries'])
            ->get();
    }

    // ── Progress ──

    /**
     * Recalculate loan progress percentages.
     */
    public function recalculateProgress(LoanDetail $loan): LoanProgress
    {
        // firstOrCreate (not `$loan->progress ?? create`) so repeated calls in a
        // single request — e.g. completing two stages then re-syncing — can't
        // double-insert against the cached-null relation and hit the unique index.
        $progress = LoanProgress::firstOrCreate(
            ['loan_id' => $loan->id],
            ['total_stages' => 10],
        );

        $mainAssignments = $loan->stageAssignments()->mainStages()->get();
        $total = $mainAssignments->count();
        $completed = $mainAssignments->whereIn('status', ['completed', 'skipped'])->count();
        // A partially disbursed / partially completed loan is not finished even when
        // every stage is closed (OTC Clearance reopens with the next cheque) — don't
        // count OTC Clearance as done, so progress stays below 100% until fully disbursed.
        if (in_array($loan->status, LoanDetail::PARTIAL_STATUSES, true)
            && in_array($mainAssignments->firstWhere('stage_key', 'otc_clearance')?->status, ['completed', 'skipped'], true)) {
            $completed--;
        }
        $percentage = $total > 0 ? round(($completed / $total) * 100, 2) : 0;

        $snapshot = $loan->stageAssignments()->get()->map(fn ($sa) => [
            'stage_key' => $sa->stage_key,
            'status' => $sa->status,
            'assigned_to' => $sa->assigned_to,
        ])->toArray();

        $progress->update([
            'total_stages' => $total,
            'completed_stages' => $completed,
            'overall_percentage' => $percentage,
            'workflow_snapshot' => $snapshot,
        ]);

        return $progress->fresh();
    }

    /**
     * Get all stage assignments for a loan, ordered by sequence.
     */
    public function getLoanStageStatus(LoanDetail $loan): Collection
    {
        return $loan->stageAssignments()
            ->with(['stage', 'assignee', 'activeQueries'])
            ->get()
            ->sortBy(fn ($sa) => ($sa->stage?->sequence_order ?? 999) * 1000 + ($sa->stage?->id ?? 999));
    }

    // ── Stage Reset (admin/CLI only) ──
    //
    // Rewinds a loan to a chosen stage/phase: the target becomes in_progress
    // (assignee resolved by role), every following stage is reset to pending,
    // dependent data (disbursement, valuation, app number, sanction/docket
    // fields) is cleared, and progress is recalculated. Shared by the
    // permission-gated web action (LoanStageController@resetStage) and the
    // `loan:set-stage` console command. This is destructive and irreversible.

    /** Parallel sub-stage keys, in flow order. */
    private const RESET_PARALLEL_SUBS = ['app_number', 'bsm_osv', 'legal_verification', 'original_document_verification', 'technical_valuation', 'sanction_decision'];

    /** Full stage flow order including parallel subs in sequence. */
    private const RESET_STAGE_ORDER = [
        'inquiry',
        'document_selection',
        'document_collection',
        'app_number',
        'bsm_osv',
        'legal_verification',
        'original_document_verification',
        'technical_valuation',
        'sanction_decision',
        'rate_pf',
        'sanction',
        'docket',
        'kfs',
        'esign',
        'disbursement',
        'otc_clearance',
    ];

    /**
     * Reset a loan back to a specific stage (optionally a specific phase/variant).
     *
     * @return array<int, string> Human-readable log lines describing what changed.
     */
    public function resetToStage(LoanDetail $loan, string $stageKey, ?int $phase = null, ?string $variant = null): array
    {
        if (! in_array($stageKey, self::RESET_STAGE_ORDER, true)) {
            throw new \InvalidArgumentException("Unknown stage key for reset: {$stageKey}");
        }

        $loan->loadMissing('stageAssignments');

        // A reset that clears the disbursement must not strand a finalized payout:
        // reversing paid tranches would orphan the payout ledger. Block it — the
        // payout has to be reversed first.
        if (array_search($stageKey, self::RESET_STAGE_ORDER, true) <= array_search('disbursement', self::RESET_STAGE_ORDER, true)
            && $loan->hasFinalizedPayout()) {
            throw new \RuntimeException('Cannot reset this loan past disbursement — one or more disbursed tranches already have a finalized payout. Reverse the payout first.');
        }

        // Phased stages default to their entry phase when none is given.
        if ($phase === null && $this->resetGetPhaseNoteKey($stageKey) !== null) {
            $phase = 1;
        }

        $users = $this->resolveResetUsers($loan);
        $role = $this->resetTargetRole($stageKey, $phase, $variant);
        $userId = $users[$role] ?? ($loan->assigned_advisor ?? $loan->created_by);

        $log = [];
        $stageName = self::RESET_STAGE_ORDER[array_search($stageKey, self::RESET_STAGE_ORDER, true)];

        // 1. Target stage → in_progress with correct phase notes + assignee.
        $assignment = $loan->stageAssignments->firstWhere('stage_key', $stageKey);
        if ($assignment) {
            $notesData = $this->resetBuildTargetNotes($stageKey, $phase, $variant, $assignment);
            $assignment->update([
                'status' => 'in_progress',
                'assigned_to' => $userId,
                'started_at' => now(),
                'completed_at' => null,
                'completed_by' => null,
                'notes' => ! empty($notesData) ? json_encode($notesData) : null,
            ]);
            $log[] = "{$stageName}: in_progress (phase ".($phase ?? '—').'), assigned to user #'.($userId ?? '—');
        }

        // 2. Loan status + stage-dependent fields.
        $currentStage = in_array($stageKey, self::RESET_PARALLEL_SUBS, true) ? 'parallel_processing' : $stageKey;
        $loanUpdate = [
            'current_stage' => $currentStage,
            'status' => 'active',
            'rejected_at' => null,
            'rejected_by' => null,
            'rejected_stage' => null,
            'rejection_reason' => null,
        ];
        $targetIdx = array_search($stageKey, self::RESET_STAGE_ORDER, true);
        if ($targetIdx <= array_search('sanction_decision', self::RESET_STAGE_ORDER, true)) {
            $loanUpdate['is_sanctioned'] = false;
        }
        if ($targetIdx <= array_search('app_number', self::RESET_STAGE_ORDER, true)) {
            $loanUpdate['application_number'] = null;
        }
        if ($targetIdx <= array_search('sanction', self::RESET_STAGE_ORDER, true)) {
            $loanUpdate['expected_docket_date'] = null;
        }
        if ($targetIdx <= array_search('docket', self::RESET_STAGE_ORDER, true)) {
            // sanctioned_amount is captured at docket (phase 2). Clear the mirror
            // column when rewinding to docket or earlier so a stale figure can't
            // drive the disbursement target; a redo re-populates it from the notes.
            $loanUpdate['sanctioned_amount'] = null;
        }
        if ($targetIdx <= array_search('disbursement', self::RESET_STAGE_ORDER, true)) {
            // Disbursement record (incl. per-entry OTC + completion_intent) is
            // deleted in resetClearRelatedData; clear the mirrored column too.
            $loanUpdate['disbursed_amount'] = null;
        }
        $loan->update($loanUpdate);
        $log[] = "Loan set to active, current_stage: {$currentStage}";

        // 3. Clear dependent records.
        $log = array_merge($log, $this->resetClearRelatedData($loan, $targetIdx));

        // 4. Parallel-processing parent + later parallel subs.
        if (in_array($stageKey, self::RESET_PARALLEL_SUBS, true)) {
            $ppAssignment = $loan->stageAssignments->firstWhere('stage_key', 'parallel_processing');
            if ($ppAssignment) {
                $ppAssignment->update([
                    'status' => 'in_progress',
                    'started_at' => $ppAssignment->started_at ?? now(),
                    'completed_at' => null,
                    'completed_by' => null,
                ]);
            }
            $log = array_merge($log, $this->resetParallelSubsAfter($loan, $stageKey));
        }

        // 5. Reset all stages after the target.
        $log = array_merge($log, $this->resetStagesAfter($loan, $stageKey));

        // 5b. Close any open (pending/responded) queries on the target stage and
        // every stage after it — a rewound stage must start clean, and a lingering
        // query would otherwise block its completion.
        $forwardKeys = array_slice(self::RESET_STAGE_ORDER, array_search($stageKey, self::RESET_STAGE_ORDER, true));
        $closedQueries = StageQuery::where('loan_id', $loan->id)
            ->whereIn('stage_key', $forwardKeys)
            ->whereIn('status', ['pending', 'responded'])
            ->update([
                'status' => StageQuery::STATUS_RESOLVED,
                'resolved_at' => now(),
                'resolved_by' => auth()->id(),
            ]);
        if ($closedQueries > 0) {
            $log[] = "Closed {$closedQueries} open ".($closedQueries === 1 ? 'query' : 'queries').' on reset stages';
        }

        // 6. Recalculate progress.
        $this->recalculateProgress($loan);
        $log[] = 'Loan progress recalculated';

        return $log;
    }

    /**
     * Resolve the default user IDs (by role) for a loan's reset targets.
     *
     * @return array{task_owner: ?int, bank_employee: ?int, office_employee: ?int, branch_manager: ?int, bdh: ?int}
     */
    public function resolveResetUsers(LoanDetail $loan): array
    {
        return [
            'task_owner' => $loan->assigned_advisor ?? $loan->created_by,
            'bank_employee' => $this->resetFindBankEmployee($loan),
            'office_employee' => $this->resetFindOfficeEmployee($loan),
            'branch_manager' => $this->resetFindUserByRoleInBranch($loan, 'branch_manager'),
            'bdh' => $this->resetFindUserByRoleInBranch($loan, 'bdh'),
        ];
    }

    /** Role that owns the target stage/phase (mirrors the loan:set-stage menu). */
    private function resetTargetRole(string $stageKey, ?int $phase, ?string $variant): string
    {
        return match ($stageKey) {
            'bsm_osv' => in_array($phase, [2, 3], true) ? 'bank_employee' : 'task_owner',
            'legal_verification' => $phase === 2 ? 'bank_employee' : 'task_owner',
            'technical_valuation' => $phase === 2 ? 'office_employee' : 'task_owner',
            'rate_pf' => $phase === 2 ? 'bank_employee' : 'task_owner',
            'sanction' => $phase === 2 ? 'bank_employee' : 'task_owner',
            'docket' => $phase === 2 ? 'office_employee' : 'task_owner',
            'esign' => in_array($phase, [2, 3], true) ? 'bank_employee' : 'task_owner',
            'disbursement' => 'office_employee',
            'otc_clearance' => $variant === 'transferred_oe' ? 'office_employee' : 'task_owner',
            'sanction_decision' => match ($variant) {
                'escalated_bm' => 'branch_manager',
                'escalated_bdh' => 'bdh',
                default => 'task_owner',
            },
            default => 'task_owner',
        };
    }

    private function resetFindBankEmployee(LoanDetail $loan): ?int
    {
        if ($loan->product_id) {
            $stages = ProductStage::where('product_id', $loan->product_id)
                ->whereHas('stage', fn ($q) => $q->where('stage_key', 'bsm_osv'))
                ->first();
            if ($stages) {
                $branch = $loan->branch_id ? Branch::with('location.parent')->find($loan->branch_id) : null;
                $userId = $stages->getUserForLocation($loan->branch_id, $branch?->location_id, $branch?->location?->parent_id);
                if ($userId && User::where('id', $userId)->where('is_active', true)->exists()) {
                    return $userId;
                }
            }
        }

        if ($loan->bank_id) {
            $cityId = $loan->branch_id ? Branch::find($loan->branch_id)?->location_id : null;
            $bank = Bank::find($loan->bank_id);
            if ($bank) {
                $defaultBEId = $bank->getDefaultEmployeeForCity($cityId);
                if ($defaultBEId && User::where('id', $defaultBEId)->where('is_active', true)->exists()) {
                    return $defaultBEId;
                }
            }
        }

        return User::whereHas('roles', fn ($q) => $q->where('slug', 'bank_employee'))
            ->where('is_active', true)
            ->first()?->id;
    }

    private function resetFindOfficeEmployee(LoanDetail $loan): ?int
    {
        if ($loan->branch_id) {
            $defaultOE = User::whereHas('branches', fn ($q) => $q->where('branches.id', $loan->branch_id)
                ->where('user_branches.is_default_office_employee', true))
                ->where('is_active', true)->first();
            if ($defaultOE) {
                return $defaultOE->id;
            }

            $branchOE = User::whereHas('roles', fn ($q) => $q->where('slug', 'office_employee'))
                ->whereHas('branches', fn ($q) => $q->where('branches.id', $loan->branch_id))
                ->where('is_active', true)->first();
            if ($branchOE) {
                return $branchOE->id;
            }
        }

        return User::whereHas('roles', fn ($q) => $q->where('slug', 'office_employee'))
            ->where('is_active', true)->first()?->id;
    }

    private function resetFindUserByRoleInBranch(LoanDetail $loan, string $role): ?int
    {
        if (! $loan->branch_id) {
            return User::whereHas('roles', fn ($q) => $q->where('slug', $role))
                ->where('is_active', true)->first()?->id;
        }

        return User::whereHas('roles', fn ($q) => $q->where('slug', $role))
            ->whereHas('branches', fn ($q) => $q->where('branches.id', $loan->branch_id))
            ->where('is_active', true)->first()?->id;
    }

    private function resetClearRelatedData(LoanDetail $loan, int $targetIdx): array
    {
        $log = [];

        if ($targetIdx <= array_search('disbursement', self::RESET_STAGE_ORDER, true)) {
            // Hard-delete the per-tranche entries too: the header is hard-deleted
            // (no soft deletes) and syncEntryRows only reconciles the CURRENT
            // detail, so leaving them would strand orphaned/duplicate cheque rows
            // that inflate the disbursed total on the next disbursement.
            $deletedEntries = $loan->disbursementEntries()->forceDelete();
            $deletedDetail = $loan->disbursement()->delete();
            if ($deletedDetail || $deletedEntries) {
                $log[] = 'Disbursement record + '.$deletedEntries.' tranche row(s) cleared';
            }
        }

        if ($targetIdx <= array_search('technical_valuation', self::RESET_STAGE_ORDER, true)) {
            if ($loan->valuationDetails()->delete()) {
                $log[] = 'Valuation details cleared';
            }
        }

        return $log;
    }

    private function resetBuildTargetNotes(string $stageKey, ?int $phase, ?string $variant, StageAssignment $assignment): array
    {
        $existing = $assignment->getNotesData();
        $phaseKey = $this->resetGetPhaseNoteKey($stageKey);

        if ($phaseKey && $phase) {
            $existing[$phaseKey] = (string) $phase;
            foreach ($this->resetGetPhaseFieldsToClear($stageKey, $phase) as $field) {
                unset($existing[$field]);
            }

            return $existing;
        }

        if ($stageKey === 'sanction_decision') {
            unset($existing['decision_action'], $existing['decision_remarks'], $existing['rejection_reason'], $existing['decided_by']);
            if ($variant === 'escalated_bm') {
                $existing['escalated_to'] = 'branch_manager';
            } elseif ($variant === 'escalated_bdh') {
                $existing['escalated_to'] = 'bdh';
            }

            return $existing;
        }

        if ($stageKey === 'otc_clearance') {
            unset($existing['handover_date']);

            return $existing;
        }

        return [];
    }

    private function resetGetPhaseNoteKey(string $stageKey): ?string
    {
        return match ($stageKey) {
            'bsm_osv' => 'bsm_osv_phase',
            'legal_verification' => 'legal_phase',
            'rate_pf' => 'rate_pf_phase',
            'sanction' => 'sanction_phase',
            'docket' => 'docket_phase',
            'esign' => 'esign_phase',
            default => null,
        };
    }

    private function resetGetPhaseFieldsToClear(string $stageKey, int $phase): array
    {
        return match ($stageKey) {
            'bsm_osv' => match ($phase) {
                2, 3 => ['bsm_status', 'bsm_remarks'],
                4 => ['stageRemarks'],
                default => [],
            },
            'legal_verification' => match ($phase) {
                2 => ['legal_status', 'legal_remarks'],
                3 => ['stageRemarks'],
                default => [],
            },
            'rate_pf' => match ($phase) {
                2 => ['interest_rate', 'repo_rate', 'bank_rate', 'rate_valid_until'],
                3 => ['pf_type', 'pf_percentage', 'pf_amount', 'gst_percentage', 'total_pf', 'total_admin_charges'],
                default => [],
            },
            'sanction' => match ($phase) {
                3 => ['sanction_date', 'sanction_conditions'],
                default => [],
            },
            'docket' => match ($phase) {
                2 => ['login_date', 'sanctioned_amount', 'sanctioned_rate', 'tenure_months', 'emi_amount'],
                default => [],
            },
            'esign' => match ($phase) {
                4 => ['stageRemarks'],
                default => [],
            },
            default => [],
        };
    }

    private function resetParallelSubsAfter(LoanDetail $loan, string $stageKey): array
    {
        $log = [];
        $idx = array_search($stageKey, self::RESET_PARALLEL_SUBS, true);
        if ($idx === false) {
            return $log;
        }

        foreach (array_slice(self::RESET_PARALLEL_SUBS, $idx + 1) as $subKey) {
            $subAssignment = $loan->stageAssignments->firstWhere('stage_key', $subKey);
            if ($subAssignment) {
                $subAssignment->update([
                    'status' => 'pending',
                    'assigned_to' => null,
                    'started_at' => null,
                    'completed_at' => null,
                    'completed_by' => null,
                    'notes' => null,
                ]);
                $log[] = ($subKey).': reset to pending';
            }
        }

        return $log;
    }

    private function resetStagesAfter(LoanDetail $loan, string $stageKey): array
    {
        $log = [];
        $idx = array_search($stageKey, self::RESET_STAGE_ORDER, true);
        if ($idx === false) {
            return $log;
        }

        // For parallel subs, reset everything from after sanction_decision onward.
        $resetFrom = $idx + 1;
        if (in_array($stageKey, self::RESET_PARALLEL_SUBS, true)) {
            $resetFrom = array_search('sanction_decision', self::RESET_STAGE_ORDER, true) + 1;
        }

        foreach (array_slice(self::RESET_STAGE_ORDER, $resetFrom) as $resetKey) {
            $resetAssignment = $loan->stageAssignments->firstWhere('stage_key', $resetKey);
            if ($resetAssignment) {
                $resetAssignment->update([
                    'status' => 'pending',
                    'assigned_to' => null,
                    'started_at' => null,
                    'completed_at' => null,
                    'completed_by' => null,
                    'notes' => null,
                ]);
                $log[] = ($resetKey).': reset to pending';
            }
        }

        // If the target is before parallel processing, reset the parent too.
        if ($idx < array_search('app_number', self::RESET_STAGE_ORDER, true)) {
            $ppAssignment = $loan->stageAssignments->firstWhere('stage_key', 'parallel_processing');
            if ($ppAssignment) {
                $ppAssignment->update([
                    'status' => 'pending',
                    'assigned_to' => null,
                    'started_at' => null,
                    'completed_at' => null,
                    'completed_by' => null,
                    'notes' => null,
                ]);
                $log[] = 'parallel_processing: reset to pending';
            }
        }

        return $log;
    }
}
